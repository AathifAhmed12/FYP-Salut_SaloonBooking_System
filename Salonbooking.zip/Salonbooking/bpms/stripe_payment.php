<?php
/**
 * Stripe Payment Handler
 * This file creates a Stripe Checkout Session and redirects customers to the payment page
 */

// Load Stripe PHP library from vendor folder
require '../vendor/autoload.php';

// Set your Stripe Secret API Key (starts with 'sk_test_' for test mode)
\Stripe\Stripe::setApiKey('sk_test_51QCdFlLrGzRaEuveCrzRu8TyHnCYfix77jbknTmfpXgeZHZwAGnrZ3AbFG0mReigcc05y766BKh6u5cce8bxdIBj00V1TEojwL');

// Start session to access session variables
session_start();

// Enable error reporting for debugging (you can disable this in production)
error_reporting(E_ALL);

// Include database connection
include('includes/dbconnection.php');

// Check if form was submitted with required data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Get the invoice amount and invoice ID from the form
    $amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;
    $invoiceId = isset($_POST['invoiceid']) ? intval($_POST['invoiceid']) : 0;
    
    // Validate that we have valid data
    if ($amount <= 0 || $invoiceId <= 0) {
        die('Error: Invalid amount or invoice ID. Please go back and try again.');
    }
    
    // Convert amount to cents (Stripe requires amount in smallest currency unit)
    // For LKR, 1 Rupee = 100 cents
    $amountInCents = $amount * 100;
    
    // Store invoice ID in session for later use
    $_SESSION['invoiceid'] = $invoiceId;
    
    try {
        // Create a Stripe Checkout Session
        // This generates a unique payment page on Stripe's servers
        // Note: Merchant email shown on Stripe page is controlled by Stripe account settings
        $session = \Stripe\Checkout\Session::create([
            
            // Specify that we only accept card payments
            'payment_method_types' => ['card'],
            
            // Define what the customer is paying for
            'line_items' => [[
                'price_data' => [
                    'currency' => 'lkr', // Sri Lankan Rupees (use lowercase)
                    'product_data' => [
                        'name' => 'Salon Service Payment - Invoice #' . $invoiceId,
                        'description' => 'Payment for salon services',
                    ],
                    'unit_amount' => $amountInCents, // Amount in cents
                ],
                'quantity' => 1, // Customer is paying once
            ]],
            
            // This is a one-time payment (not a subscription)
            'mode' => 'payment',
            
            // Don't collect billing address to minimize displayed information
            'billing_address_collection' => 'auto',
            
            // Where to redirect after successful payment
            // {CHECKOUT_SESSION_ID} is automatically replaced by Stripe
            'success_url' => 'http://localhost/Salonbooking/bpms/view-invoice.php?session_id={CHECKOUT_SESSION_ID}&invoiceid=' . $invoiceId,
            
            // Where to redirect if customer cancels
            'cancel_url' => 'http://localhost/Salonbooking/bpms/view-invoice.php?invoiceid=' . $invoiceId . '&payment=cancelled',
            
            // Additional metadata to track this payment
            'metadata' => [
                'invoice_id' => $invoiceId,
                'billing_id' => $invoiceId,
                'merchant_email' => 'salutowner@gmail.com',
            ],
        ]);
        
        // Redirect customer to Stripe's hosted payment page
        header("Location: " . $session->url);
        exit();
        
    } catch (\Stripe\Exception\ApiErrorException $e) {
        // Handle Stripe API errors
        echo '<div style="padding: 20px; background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 5px; margin: 20px;">';
        echo '<h3>Payment Error</h3>';
        echo '<p>We encountered an error while processing your payment request:</p>';
        echo '<p><strong>' . htmlspecialchars($e->getMessage()) . '</strong></p>';
        echo '<p><a href="view-invoice.php?invoiceid=' . $invoiceId . '">Go back to invoice</a></p>';
        echo '</div>';
        
    } catch (Exception $e) {
        // Handle general errors
        echo '<div style="padding: 20px; background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 5px; margin: 20px;">';
        echo '<h3>System Error</h3>';
        echo '<p>An unexpected error occurred:</p>';
        echo '<p><strong>' . htmlspecialchars($e->getMessage()) . '</strong></p>';
        echo '<p><a href="view-invoice.php?invoiceid=' . $invoiceId . '">Go back to invoice</a></p>';
        echo '</div>';
    }
    
} else {
    // If someone tries to access this file directly without posting data
    echo '<div style="padding: 20px; background: #fff3cd; color: #856404; border: 1px solid #ffeeba; border-radius: 5px; margin: 20px;">';
    echo '<h3>Invalid Access</h3>';
    echo '<p>Please initiate payment from the invoice page.</p>';
    echo '<p><a href="invoice-history.php">View your invoices</a></p>';
    echo '</div>';
}
?>
