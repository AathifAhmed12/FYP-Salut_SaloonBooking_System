<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bpmsaid']==0)) {
  header('location:logout.php');
  } else{


// Handle Delete
if($_GET['delid']){
$sid=$_GET['delid'];
mysqli_query($con,"delete from tblbook where ID ='$sid'");
echo "<script>alert('Appointment Deleted');</script>";
echo "<script>window.location.href='accepted-appointment.php'</script>";
}

// Handle Create Invoice (Send Invoice)
if(isset($_GET['createinvoice'])){
    $aptid = intval($_GET['createinvoice']); // Sanitize
    
    // Get appointment details
    $aptQuery = mysqli_query($con, "SELECT UserID, ServiceName FROM tblbook WHERE ID='$aptid'");
    $aptData = mysqli_fetch_array($aptQuery);
    
    if($aptData){
        $userid = intval($aptData['UserID']);
        $serviceName = $aptData['ServiceName'];
        
        // Generate random invoice number (same for all services in this appointment)
        $invoiceid = mt_rand(100000000, 999999999);
        
        // Split service names by comma (handles both single and multiple services)
        $serviceNames = array_map('trim', explode(',', $serviceName));
        
        // ============================================
        // OPTIMIZED: Fetch all service IDs in ONE query (fixes N+1 problem)
        // ============================================
        $serviceNamesEscaped = array();
        foreach($serviceNames as $name){
            $serviceNamesEscaped[] = "'" . mysqli_real_escape_string($con, $name) . "'";
        }
        $serviceNamesList = implode(',', $serviceNamesEscaped);
        
        // Single query to get all service IDs at once
        $serviceQuery = mysqli_query($con, "SELECT ID, ServiceName FROM tblservices WHERE ServiceName IN ($serviceNamesList)");
        $serviceMap = array(); // Map service name to ID
        while($serviceRow = mysqli_fetch_array($serviceQuery)){
            $serviceMap[$serviceRow['ServiceName']] = $serviceRow['ID'];
        }
        
        $invoiceCreated = false;
        $notFoundServices = array();
        
        // OPTIMIZED: Batch insert invoices (faster than individual inserts)
        $insertValues = array();
        foreach($serviceNames as $singleServiceName){
            if(isset($serviceMap[$singleServiceName])){
                $serviceId = intval($serviceMap[$singleServiceName]);
                $invoiceidEscaped = mysqli_real_escape_string($con, $invoiceid);
                $insertValues[] = "('$userid', '$serviceId', '$invoiceidEscaped', 'Pending')";
            } else {
                $notFoundServices[] = $singleServiceName;
            }
        }
        
        // Batch insert all invoices at once (much faster!)
        if(count($insertValues) > 0){
            $insertQuery = mysqli_query($con, "INSERT INTO tblinvoice(Userid, ServiceId, BillingId, PaymentStatus) VALUES " . implode(',', $insertValues));
            if($insertQuery){
                $invoiceCreated = true;
            }
        }
        
        if($invoiceCreated){
            // OPTIMIZED: Send email asynchronously (non-blocking)
            include('../includes/email-config.php');
            $userQuery = mysqli_query($con, "SELECT tbluser.FirstName, tbluser.LastName, tbluser.Email, tblbook.AptNumber 
                                            FROM tbluser JOIN tblbook ON tbluser.ID = tblbook.UserID WHERE tblbook.ID='$aptid'");
            $userData = mysqli_fetch_array($userQuery);
            if($userData){
                $totalQuery = mysqli_query($con, "SELECT SUM(tblservices.Cost) as totalAmount 
                                                  FROM tblinvoice JOIN tblservices ON tblinvoice.ServiceId = tblservices.ID 
                                                  WHERE tblinvoice.BillingId='$invoiceid'");
                $totalData = mysqli_fetch_array($totalQuery);
                $invoiceData = array(
                    'invoiceNumber' => $invoiceid,
                    'appointmentNumber' => $userData['AptNumber'],
                    'customerName' => $userData['FirstName'] . ' ' . $userData['LastName'],
                    'customerEmail' => $userData['Email'],
                    'services' => $serviceName,
                    'totalAmount' => $totalData['totalAmount'] ? $totalData['totalAmount'] : 0
                );
                // Send invoice email asynchronously (non-blocking)
                sendInvoiceNotificationEmailAsync($invoiceData);
            }
            
            if(count($notFoundServices) > 0){
                echo "<script>alert('Invoice created successfully! Invoice Number: $invoiceid\\n\\nEmail sent to customer.\\n\\nNote: Some services were not found: " . implode(', ', $notFoundServices) . "');</script>";
            } else {
                echo "<script>alert('Invoice created successfully! Invoice Number: $invoiceid\\n\\nEmail sent to customer.');</script>";
            }
            echo "<script>window.location.href='accepted-appointment.php'</script>";
        } else {
            if(count($notFoundServices) > 0){
                echo "<script>alert('Services not found in database: " . implode(', ', $notFoundServices) . "\\nPlease check service names.');</script>";
            } else {
                echo "<script>alert('Error creating invoice. Please try again.');</script>";
            }
        }
    }
}

  ?>
<!DOCTYPE HTML>
<html>
<head>
<title>SBS || Accepted Appointment</title>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!-- Modern Dark Theme -->
<link href="css/admin-dark-theme.css" rel='stylesheet' type='text/css' />
<!--//Metis Menu -->
<style>
/* Professional Status Badges */
.status-badge {
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
    display: inline-block;
    text-align: center;
    min-width: 80px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.status-accepted {
    background: #28a745;
    color: #fff;
}

/* Standardized Button Styling */
.btn-action {
    min-width: 80px;
    padding: 6px 12px;
    font-size: 12px;
    font-weight: 500;
    text-align: center;
    margin: 2px;
    border-radius: 4px;
}

/* Table Cell Alignment */
.table-bordered td {
    vertical-align: middle !important;
}

.action-cell {
    text-align: center;
}

/* Service/Stylist Info */
.info-text {
    font-size: 13px;
    color: #333;
}
</style>
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		 <?php include_once('includes/header.php');?>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					<h3 class="title1">Accepted Appointment</h3>
					
					
				
					<div class="table-responsive bs-example widget-shadow">
						<h4>Accepted Appointments:</h4>
						<table class="table table-bordered"> 
							<thead> 
								<tr> 
									<th style="text-align:center;">#</th> 
									<th style="text-align:center;">Appointment Number</th> 
									<th style="text-align:center;">Name</th>
									<th style="text-align:center;">Mobile Number</th> 
									<th style="text-align:center;">Appointment Date</th>
									<th style="text-align:center;">Appointment Time</th>
									<th style="text-align:center;">Service</th>
									<th style="text-align:center;">Stylist</th>
									<th style="text-align:center;">Status</th>
									<th style="text-align:center;">Actions</th>
									<th style="text-align:center;">Create Invoice</th>
								</tr> 
							</thead> 
							<tbody>
<?php
$ret=mysqli_query($con,"select tbluser.ID as uid, tbluser.FirstName, tbluser.LastName, tbluser.Email, tbluser.MobileNumber, tblbook.ID as bid, tblbook.AptNumber, tblbook.AptDate, tblbook.AptTime, tblbook.ServiceName, tblbook.StylistName, tblbook.Message, tblbook.BookingDate, tblbook.Status from tblbook join tbluser on tbluser.ID=tblbook.UserID where tblbook.Status='Selected' ORDER BY tblbook.ID DESC");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {
?>
						 <tr> <td style="text-align:center;"><strong><?php echo $cnt;?></strong></td> <td style="text-align:center;"><strong><?php echo $row['AptNumber'];?></strong></td> <td><?php echo $row['FirstName'];?> <?php echo $row['LastName'];?></td><td style="text-align:center;"><?php echo $row['MobileNumber'];?></td><td style="text-align:center;"><?php echo date('d M Y', strtotime($row['AptDate']));?></td> <td style="text-align:center;"><?php echo date('h:i A', strtotime($row['AptTime']));?></td><td style="text-align:center;" class="info-text"><?php echo $row['ServiceName'];?></td><td style="text-align:center;" class="info-text"><?php echo $row['StylistName'];?></td><td style="text-align:center;"><span class="status-badge status-accepted">Accepted</span></td><td class="action-cell"><a href="view-appointment.php?viewid=<?php echo $row['bid'];?>" class="btn btn-info btn-sm btn-action">View</a> <a href="accepted-appointment.php?delid=<?php echo $row['bid'];?>" class="btn btn-danger btn-sm btn-action" onClick="return confirm('Are you sure you want to delete?')">Delete</a></td><td class="action-cell"><a href="accepted-appointment.php?createinvoice=<?php echo $row['bid'];?>" class="btn btn-primary btn-sm btn-action" onClick="return confirm('Create invoice for this appointment?')">Send Invoice</a></td></tr>   
<?php 
$cnt=$cnt+1;
}?></tbody> </table> 
					</div>
				</div>
			</div>
		</div>
		<!--footer-->
		 <?php include_once('includes/footer.php');?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>
<?php }  ?>