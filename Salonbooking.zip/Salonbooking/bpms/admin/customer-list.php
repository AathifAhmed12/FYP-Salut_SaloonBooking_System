<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bpmsaid']==0)) {
  header('location:logout.php');
  } else{

if($_GET['delid']){
$sid=$_GET['delid'];
mysqli_query($con,"delete from tbluser where ID ='$sid'");
echo "<script>alert('Data Deleted');</script>";
echo "<script>window.location.href='unreadenq.php'</script>";
          }

  ?>
<!DOCTYPE HTML>
<html>
<head>
<title>SBS || Customer List</title>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!-- Modern Dark Theme -->
<link href="css/admin-dark-theme.css" rel='stylesheet' type='text/css' />
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		 <?php include_once('includes/header.php');?>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					<h3 class="title1">Customer List</h3>
					
					
				
					<div class="table-responsive bs-example widget-shadow">
						<h4>Customer List:</h4>
						<table class="table table-bordered"> <thead> <tr> <th>#</th> <th>Name</th> <th>Mobile Number</th><th>Email</th> <th>RegistrationDate</th><th>Action</th> </tr> </thead> <tbody>
<?php
// OPTIMIZED: Add pagination for better performance
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

$countQuery = mysqli_query($con, "SELECT COUNT(*) as total FROM tbluser");
$countRow = mysqli_fetch_array($countQuery);
$totalRecords = $countRow['total'];
$totalPages = ceil($totalRecords / $perPage);

$ret = mysqli_query($con, "SELECT * FROM tbluser ORDER BY ID DESC LIMIT $perPage OFFSET $offset");
$cnt = $offset + 1;
while ($row=mysqli_fetch_array($ret)) {

?>

						 <tr> <th scope="row"><?php echo $cnt;?></th> <td><?php  echo $row['FirstName'];?> <?php  echo $row['LastName'];?></td> <td><?php  echo $row['MobileNumber'];?></td><td><?php  echo $row['Email'];?></td><td><?php  echo $row['RegDate'];?></td> 
						 	<td> <a href="add-customer-services.php?addid=<?php echo $row['ID'];?>" class="btn btn-primary">Create Invoice</a>
<a href="customer-list.php?delid=<?php echo $row['ID'];?>" class="btn btn-danger" onClick="return confirm('Are you sure you want to delete?')">Delete</a>
						 		</td> </tr>   <?php 
$cnt=$cnt+1;
}?></tbody> </table> 
						
						<!-- Pagination Controls -->
						<?php if ($totalPages > 1): ?>
						<div class="pagination-wrapper" style="margin-top: 20px; text-align: center;">
							<nav>
								<ul class="pagination" style="display: inline-block;">
									<?php if ($page > 1): ?>
										<li><a href="?page=<?php echo ($page - 1); ?>" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
									<?php else: ?>
										<li class="disabled"><span aria-hidden="true">&laquo;</span></li>
									<?php endif; ?>
									
									<?php
									$startPage = max(1, $page - 2);
									$endPage = min($totalPages, $page + 2);
									for ($i = $startPage; $i <= $endPage; $i++):
									?>
										<li <?php echo ($i == $page) ? 'class="active"' : ''; ?>>
											<a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
										</li>
									<?php endfor; ?>
									
									<?php if ($page < $totalPages): ?>
										<li><a href="?page=<?php echo ($page + 1); ?>" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
									<?php else: ?>
										<li class="disabled"><span aria-hidden="true">&raquo;</span></li>
									<?php endif; ?>
								</ul>
							</nav>
							<p style="margin-top: 10px; color: #848484;">
								Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $perPage, $totalRecords); ?> of <?php echo $totalRecords; ?> customers
							</p>
						</div>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
		<!--footer-->
		 <?php include_once('includes/footer.php');?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>
<?php }  ?>