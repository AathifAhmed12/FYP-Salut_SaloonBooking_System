<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['submit']))
  {
    $contactno=$_POST['contactno'];
    $email=$_POST['email'];

    $query=mysqli_query($con,"select ID from tbladmin where Email='$email' and MobileNumber='$contactno' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
      $_SESSION['contactno']=$contactno;
      $_SESSION['email']=$email;
     header('location:reset-password.php');
    }
    else{
      $msg="Invalid Details. Please try again.";
    }
  }
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Salut SBS | Forgot Password Page</title>

<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Font CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- Webfonts -->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!-- Animate CSS -->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
<script>
    new WOW().init();
</script>
<!-- Custom JavaScript -->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!-- Modern Dark Theme -->
<link href="css/admin-dark-theme.css" rel='stylesheet' type='text/css' />

<style>
    body {
        background: url('images/background.jpg') no-repeat center center fixed;
        background-size: cover;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .login-page {
        background: rgba(255, 255, 255, 0.9);
        padding: 50px;
        border-radius: 10px;
        box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.2);
        width: 400px;
    }
    .login-body input[type="text"] {
        border: 1px solid #ccc;
        border-radius: 4px;
        padding: 15px;
        width: 100%;
        margin-bottom: 20px;
    }
    .login-body input[type="submit"] {
        background-color: #28a745;
        color: #fff;
        border: none;
        padding: 15px;
        width: 100%;
        cursor: pointer;
        border-radius: 4px;
        font-size: 16px;
    }
    .login-body input[type="submit"]:hover {
        background-color: #218838;
    }
    .forgot-grid {
        text-align: center;
        margin-top: 10px;
    }
    .forgot a {
        color: #007bff;
        text-decoration: none;
    }
    .forgot a:hover {
        text-decoration: underline;
    }
    .login-top h4 {
        text-align: center;
        font-size: 24px;
        margin-bottom: 20px;
    }
</style>
</head> 
<body>
    <div class="login-page">
        <div class="login-top">
            <h4>Forgot your Password?</h4>
        </div>
        <div class="login-body">
            <form role="form" method="post" action="">
                <p style="font-size:16px; color:red" align="center">
                    <?php if($msg){ echo $msg; } ?>
                </p>
                <input type="text" name="email" class="lock" placeholder="Email" required="true">
                <input type="text" name="contactno" class="lock" placeholder="Mobile Number" required="true" maxlength="10" pattern="[0-9]+">
                <input type="submit" name="submit" value="Reset Password">
                <div class="forgot-grid">
                    <div class="forgot">
                        <a href="index.php">Already have an account?</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
