<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bpmsaid']==0)) {
  header('location:logout.php');
  } else{

// Handle Delete
if($_GET['delid']){
$sid=$_GET['delid'];
mysqli_query($con,"delete from tblbook where ID ='$sid'");
echo "<script>alert('Appointment Deleted');</script>";
echo "<script>window.location.href='new-appointment.php'</script>";
}

// Handle Accept Appointment
if(isset($_GET['acceptid'])){
    $aptid = intval($_GET['acceptid']); // Sanitize
    $query = mysqli_query($con, "UPDATE tblbook SET Status='Selected', Remark='Appointment Accepted by Admin' WHERE ID='$aptid'");
    if($query){
        // ============================================
        // OPTIMIZED: Send email asynchronously (non-blocking)
        // ============================================
        include('../includes/email-config.php');
        
        // Get appointment and customer details
        $aptQuery = mysqli_query($con, "SELECT tblbook.*, tbluser.FirstName, tbluser.LastName, tbluser.Email, tbluser.MobileNumber 
                                        FROM tblbook 
                                        JOIN tbluser ON tblbook.UserID = tbluser.ID 
                                        WHERE tblbook.ID='$aptid'");
        $aptData = mysqli_fetch_array($aptQuery);
        
        if($aptData){
            // Prepare booking data for email
            $bookingData = array(
                'appointmentNumber' => $aptData['AptNumber'],
                'customerName' => $aptData['FirstName'] . ' ' . $aptData['LastName'],
                'customerEmail' => $aptData['Email'],
                'appointmentDate' => $aptData['AptDate'],
                'appointmentTime' => $aptData['AptTime'],
                'services' => $aptData['ServiceName'],
                'stylist' => $aptData['StylistName']
            );
            
            // Send acceptance email asynchronously (non-blocking)
            sendAppointmentAcceptedEmailAsync($bookingData);
        }
        
        echo "<script>alert('Appointment Accepted Successfully! Email sent to customer.');</script>";
        echo "<script>window.location.href='new-appointment.php'</script>";
    }
}

// Handle Decline Appointment
if(isset($_GET['declineid'])){
    $aptid = intval($_GET['declineid']); // Sanitize
    $query = mysqli_query($con, "UPDATE tblbook SET Status='Rejected', Remark='Appointment Declined by Admin' WHERE ID='$aptid'");
    if($query){
        // ============================================
        // OPTIMIZED: Send email asynchronously (non-blocking)
        // ============================================
        include('../includes/email-config.php');
        
        // Get appointment and customer details
        $aptQuery = mysqli_query($con, "SELECT tblbook.*, tbluser.FirstName, tbluser.LastName, tbluser.Email, tbluser.MobileNumber 
                                        FROM tblbook 
                                        JOIN tbluser ON tblbook.UserID = tbluser.ID 
                                        WHERE tblbook.ID='$aptid'");
        $aptData = mysqli_fetch_array($aptQuery);
        
        if($aptData){
            // Prepare booking data for email
            $bookingData = array(
                'appointmentNumber' => $aptData['AptNumber'],
                'customerName' => $aptData['FirstName'] . ' ' . $aptData['LastName'],
                'customerEmail' => $aptData['Email'],
                'appointmentDate' => $aptData['AptDate'],
                'appointmentTime' => $aptData['AptTime'],
                'services' => $aptData['ServiceName'],
                'remark' => $aptData['Remark']
            );
            
            // Send rejection email asynchronously (non-blocking)
            sendAppointmentRejectedEmailAsync($bookingData);
        }
        
        echo "<script>alert('Appointment Declined! Email sent to customer.');</script>";
        echo "<script>window.location.href='new-appointment.php'</script>";
    }
}

  ?>
<!DOCTYPE HTML>
<html>
<head>
<title>SBS || New Appointment</title>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!-- Modern Dark Theme -->
<link href="css/admin-dark-theme.css" rel='stylesheet' type='text/css' />
<!--//Metis Menu -->
<style>
/* Professional Status Badges */
.status-badge {
    padding: 6px 12px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
    display: inline-block;
    text-align: center;
    min-width: 80px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.status-pending {
    background: #ffc107;
    color: #000;
}

/* Standardized Button Styling */
.btn-action {
    min-width: 80px;
    padding: 6px 12px;
    font-size: 12px;
    font-weight: 500;
    text-align: center;
    margin: 2px;
    border-radius: 4px;
}

/* Table Cell Alignment */
.table-bordered td {
    vertical-align: middle !important;
}

.action-cell {
    text-align: center;
}

/* Service/Stylist Info */
.info-text {
    font-size: 13px;
    color: #333;
}
</style>
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		 <?php include_once('includes/header.php');?>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					<h3 class="title1">New Appointment</h3>
					
					
				
					<div class="table-responsive bs-example widget-shadow">
						<h4>Pending Appointments (Awaiting Response):</h4>
						<table class="table table-bordered"> 
							<thead> 
								<tr> 
									<th style="text-align:center;">#</th> 
									<th style="text-align:center;">Appointment Number</th> 
									<th style="text-align:center;">Name</th>
									<th style="text-align:center;">Mobile Number</th> 
									<th style="text-align:center;">Appointment Date</th>
									<th style="text-align:center;">Appointment Time</th>
									<th style="text-align:center;">Service</th>
									<th style="text-align:center;">Stylist</th>
									<th style="text-align:center;">Status</th>
									<th style="text-align:center;">Actions</th>
								</tr> 
							</thead> 
							<tbody>
<?php
$ret=mysqli_query($con,"select tbluser.ID as uid, tbluser.FirstName, tbluser.LastName, tbluser.Email, tbluser.MobileNumber, tblbook.ID as bid, tblbook.AptNumber, tblbook.AptDate, tblbook.AptTime, tblbook.ServiceName, tblbook.StylistName, tblbook.Message, tblbook.BookingDate, tblbook.Status from tblbook join tbluser on tbluser.ID=tblbook.UserID where tblbook.Status is null ORDER BY tblbook.ID DESC");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {
?>
						 <tr> <td style="text-align:center;"><strong><?php echo $cnt;?></strong></td> <td style="text-align:center;"><strong><?php echo $row['AptNumber'];?></strong></td> <td><?php echo $row['FirstName'];?> <?php echo $row['LastName'];?></td><td style="text-align:center;"><?php echo $row['MobileNumber'];?></td><td style="text-align:center;"><?php echo date('d M Y', strtotime($row['AptDate']));?></td> <td style="text-align:center;"><?php echo date('h:i A', strtotime($row['AptTime']));?></td><td style="text-align:center;" class="info-text"><?php echo $row['ServiceName'];?></td><td style="text-align:center;" class="info-text"><?php echo $row['StylistName'];?></td><td style="text-align:center;"><span class="status-badge status-pending">Pending</span></td><td class="action-cell"><a href="new-appointment.php?acceptid=<?php echo $row['bid'];?>" class="btn btn-success btn-sm btn-action" onClick="return confirm('Accept this appointment?')">Accept</a> <a href="new-appointment.php?declineid=<?php echo $row['bid'];?>" class="btn btn-warning btn-sm btn-action" onClick="return confirm('Decline this appointment?')">Decline</a><br><a href="view-appointment.php?viewid=<?php echo $row['bid'];?>" class="btn btn-info btn-sm btn-action">View</a> <a href="new-appointment.php?delid=<?php echo $row['bid'];?>" class="btn btn-danger btn-sm btn-action" onClick="return confirm('Are you sure you want to delete?')">Delete</a></td></tr>   
<?php 
$cnt=$cnt+1;
}?></tbody> </table> 
					</div>
				</div>
			</div>
		</div>
		<!--footer-->
		 <?php include_once('includes/footer.php');?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>
<?php }  ?>