<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bpmsaid']==0)) {
  header('location:logout.php');
  } else{

if(isset($_POST['submit']))
  {
    $stylistname=$_POST['stylistname'];
    $stylistemail=$_POST['stylistemail'];
    $stylistphone=$_POST['stylistphone'];
    $specialization=$_POST['specialization'];
    $experience=$_POST['experience'];
    $bio=$_POST['bio'];
    $status=$_POST['status'];
   
 $eid=$_GET['editid'];
     
    $query=mysqli_query($con, "update tblstylist set StylistName='$stylistname',StylistEmail='$stylistemail',StylistPhone='$stylistphone',Specialization='$specialization',Experience='$experience',Bio='$bio',Status='$status' where ID='$eid' ");
    if ($query) {
  
    echo "<script>alert('Stylist has been Updated.');</script>";
  }
  else
    {
      
      echo "<script>alert('Something Went Wrong. Please try again.');</script>";
    }

  
}
  ?>
<!DOCTYPE HTML>
<html>
<head>
<title>SBS | Update Stylist</title>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!-- Modern Dark Theme -->
<link href="css/admin-dark-theme.css" rel='stylesheet' type='text/css' />
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		 <?php include_once('includes/header.php');?>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					<h3 class="title1">Update Stylist</h3>
					<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
							<h4>Stylist Information:</h4>
						</div>
						<div class="form-body">
							<form method="post">
								<p style="font-size:16px; color:red" align="center"> <?php if($msg){
    echo $msg;
  }  ?> </p>

<?php
$eid=$_GET['editid'];
$ret=mysqli_query($con,"select * from tblstylist where ID='$eid'");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {

?>
  
							 <div class="form-group"> <label for="stylistname">Stylist Name</label> <input type="text" class="form-control" id="stylistname" name="stylistname" placeholder="Stylist Name" value="<?php echo $row['StylistName'];?>" required="true"> </div>
							 <div class="form-group"> <label for="stylistemail">Email</label> <input type="email" class="form-control" id="stylistemail" name="stylistemail" placeholder="Email Address" value="<?php echo $row['StylistEmail'];?>" required="true"> </div>
							 <div class="form-group"> <label for="stylistphone">Phone Number</label> <input type="text" class="form-control" id="stylistphone" name="stylistphone" placeholder="Phone Number" value="<?php echo $row['StylistPhone'];?>" required="true"> </div>
							 <div class="form-group"> <label for="specialization">Specialization</label> <input type="text" class="form-control" id="specialization" name="specialization" placeholder="e.g., Hair Styling, Hair Color, Beard Trim" value="<?php echo $row['Specialization'];?>" required="true"> </div>
							 <div class="form-group"> <label for="experience">Experience</label> <input type="text" class="form-control" id="experience" name="experience" placeholder="e.g., 5 years" value="<?php echo $row['Experience'];?>" required="true"> </div>
							 <div class="form-group"> <label for="bio">Bio</label> <textarea class="form-control" id="bio" name="bio" placeholder="Brief description about the stylist" required="true"><?php echo $row['Bio'];?></textarea> </div>
							 <div class="form-group"> <label for="status">Status</label> 
							 	<select class="form-control" id="status" name="status" required="true">
							 		<option value="">Select Status</option>
							 		<option value="Active" <?php if($row['Status']=='Active') echo 'selected';?>>Active</option>
							 		<option value="Inactive" <?php if($row['Status']=='Inactive') echo 'selected';?>>Inactive</option>
							 	</select>
							 </div>
							  <button type="submit" name="submit" class="btn btn-default">Update Stylist</button> </form> 
						</div>
						<?php } ?>
					</div>
				
				
			</div>
		</div>
		</div>
		 <?php include_once('includes/footer.php');?>
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.js"> </script>
</body>
</html>
<?php } ?>
