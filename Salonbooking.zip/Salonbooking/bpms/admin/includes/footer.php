<!--footer-->
    <div class="footer">
       <p> SALUT Admin Panel.</p>
    </div>
        <!--//footer-->