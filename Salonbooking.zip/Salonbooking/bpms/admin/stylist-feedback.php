<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['bpmsaid']==0)) {
  header('location:logout.php');
} else {
    
// Handle status update
if(isset($_GET['updatestatus'])) {
    $reviewid = $_GET['reviewid'];
    $newstatus = $_GET['newstatus'];
    
    $query = mysqli_query($con, "UPDATE tblstylist_reviews SET Status='$newstatus' WHERE ID='$reviewid'");
    if($query) {
        echo '<script>alert("Review status updated successfully")</script>';
        echo "<script>window.location.href='stylist-feedback.php'</script>";
    }
}

// Handle delete
if(isset($_GET['del'])) {
    $reviewid = $_GET['del'];
    mysqli_query($con, "DELETE FROM tblstylist_reviews WHERE ID='$reviewid'");
    echo "<script>alert('Review deleted');</script>"; 
    echo "<script>window.location.href='stylist-feedback.php'</script>";
}

?>
<!DOCTYPE HTML>
<html>
<head>
<title>SALUT | Stylist Feedback</title>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!-- Modern Dark Theme -->
<link href="css/admin-dark-theme.css" rel='stylesheet' type='text/css' />

<style>
    .star-display {
        color: #ffc107;
        font-size: 18px;
    }
    .review-text {
        max-width: 400px;
        white-space: normal;
        word-wrap: break-word;
    }
    .status-badge {
        padding: 5px 15px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: bold;
    }
    .status-approved {
        background: #d4edda;
        color: #155724;
    }
    .status-pending {
        background: #fff3cd;
        color: #856404;
    }
    .status-rejected {
        background: #f8d7da;
        color: #721c24;
    }
    .filter-section {
        margin-bottom: 20px;
        padding: 15px;
        background: #f8f9fa;
        border-radius: 5px;
    }
</style>
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
		<!--left-fixed -navigation-->
		 <?php include_once('includes/sidebar.php');?>
		<!--left-fixed -navigation-->
		<!-- header-starts -->
		 <?php include_once('includes/header.php');?>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="tables">
					<h3 class="title1">Stylist Feedback & Reviews</h3>
					
					<!-- Filter Section -->
					<div class="filter-section">
                        <form method="get" class="form-inline">
                            <label>Filter by Stylist:</label>
                            <select name="stylist" class="form-control" style="margin: 0 10px;" onchange="this.form.submit()">
                                <option value="">All Stylists</option>
                                <?php
                                $stylistQuery = mysqli_query($con, "SELECT * FROM tblstylist ORDER BY StylistName");
                                while($stylist = mysqli_fetch_array($stylistQuery)) {
                                    $selected = (isset($_GET['stylist']) && $_GET['stylist'] == $stylist['ID']) ? 'selected' : '';
                                    echo '<option value="'.$stylist['ID'].'" '.$selected.'>'.$stylist['StylistName'].'</option>';
                                }
                                ?>
                            </select>
                            
                            <label style="margin-left: 20px;">Filter by Status:</label>
                            <select name="status" class="form-control" style="margin: 0 10px;" onchange="this.form.submit()">
                                <option value="">All Reviews</option>
                                <option value="Approved" <?php if(isset($_GET['status']) && $_GET['status']=='Approved') echo 'selected'; ?>>Visible to Customers</option>
                                <option value="Pending" <?php if(isset($_GET['status']) && $_GET['status']=='Pending') echo 'selected'; ?>>Pending Review</option>
                                <option value="Rejected" <?php if(isset($_GET['status']) && $_GET['status']=='Rejected') echo 'selected'; ?>>Hidden from Customers</option>
                            </select>
                            
                            <?php if(isset($_GET['stylist']) || isset($_GET['status'])) { ?>
                                <a href="stylist-feedback.php" class="btn btn-default" style="margin-left: 10px;">Clear Filters</a>
                            <?php } ?>
                        </form>
                    </div>
					
					<div class="table-responsive bs-example widget-shadow">
						<h4>Manage Customer Reviews:</h4>
						<table class="table table-bordered"> 
							<thead> 
								<tr> 
									<th>#</th> 
									<th>Stylist Name</th>
									<th>Customer Name</th>
									<th>Rating</th>
									<th>Review</th>
									<th>Review Date</th>
									<th>Status</th>
									<th>Action</th>
								</tr> 
							</thead> 
							<tbody>
<?php
// Build query with filters
$whereClause = "1=1";
if(isset($_GET['stylist']) && $_GET['stylist'] != '') {
    $stylistFilter = $_GET['stylist'];
    $whereClause .= " AND ts.ID='$stylistFilter'";
}
if(isset($_GET['status']) && $_GET['status'] != '') {
    $statusFilter = $_GET['status'];
    $whereClause .= " AND tr.Status='$statusFilter'";
}

$ret = mysqli_query($con, "SELECT tr.*, ts.StylistName, tu.FirstName, tu.LastName, tu.Email 
                           FROM tblstylist_reviews tr 
                           JOIN tblstylist ts ON tr.StylistID = ts.ID 
                           JOIN tbluser tu ON tr.UserID = tu.ID 
                           WHERE $whereClause
                           ORDER BY tr.ReviewDate DESC");
$cnt = 1;
$count = mysqli_num_rows($ret);

if($count > 0) {
    while ($row = mysqli_fetch_array($ret)) {
?>						
								<tr> 
									<th scope="row"><?php echo $cnt;?></th> 
									<td><?php echo $row['StylistName'];?></td>
									<td><?php echo $row['FirstName'].' '.$row['LastName'];?><br>
									    <small><?php echo $row['Email'];?></small>
									</td>
									<td>
									    <div class="star-display">
									        <?php
									        for($i = 1; $i <= 5; $i++) {
									            if($i <= $row['Rating']) {
									                echo '<i class="fa fa-star"></i>';
									            } else {
									                echo '<i class="fa fa-star-o"></i>';
									            }
									        }
									        ?>
									    </div>
									    <small><?php echo $row['Rating'];?>/5</small>
									</td>
									<td class="review-text"><?php echo $row['Review'] ? htmlspecialchars($row['Review']) : '<em>No written review</em>';?></td>
									<td><?php echo date('M d, Y', strtotime($row['ReviewDate']));?><br>
									    <small><?php echo date('h:i A', strtotime($row['ReviewDate']));?></small>
									</td>
								<td>
								    <?php 
								    $status = $row['Status'];
								    $statusClass = 'status-pending';
								    $statusLabel = 'Pending';
								    
								    if($status == 'Approved') {
								        $statusClass = 'status-approved';
								        $statusLabel = 'Visible';
								    } elseif($status == 'Rejected') {
								        $statusClass = 'status-rejected';
								        $statusLabel = 'Hidden';
								    }
								    ?>
								    <span class="status-badge <?php echo $statusClass;?>"><?php echo $statusLabel;?></span>
								</td>
								<td>
								    <?php if($status != 'Approved') { ?>
								        <a href="stylist-feedback.php?updatestatus=1&reviewid=<?php echo $row['ID'];?>&newstatus=Approved" class="btn btn-success btn-sm" style="min-width: 75px; margin-bottom: 3px;" title="Show this review to customers">
								            <i class="fa fa-eye"></i> Show
								        </a>
								    <?php } ?>
								    
								    <?php if($status != 'Rejected') { ?>
								        <a href="stylist-feedback.php?updatestatus=1&reviewid=<?php echo $row['ID'];?>&newstatus=Rejected" class="btn btn-warning btn-sm" style="min-width: 75px; margin-bottom: 3px;" title="Hide this review from customers">
								            <i class="fa fa-eye-slash"></i> Hide
								        </a>
								    <?php } ?>
								    
								    <a href="stylist-feedback.php?del=<?php echo $row['ID'];?>" class="btn btn-danger btn-sm" style="min-width: 75px; margin-bottom: 3px;" onclick="return confirm('Are you sure you want to delete this review?');" title="Delete permanently">
								        <i class="fa fa-trash"></i> Remove
								    </a>
								</td>
								</tr>   
<?php 
        $cnt = $cnt + 1;
    }
} else { ?>
                                <tr>
                                    <td colspan="8" style="color: red; text-align: center;">No reviews found</td>
                                </tr>
<?php } ?>						
							</tbody> 
						</table>
						
						<?php if($count > 0) { ?>
						<p><strong>Total Reviews:</strong> <?php echo $count;?></p>
						<?php } ?>
					</div>
					
					<!-- Summary Stats -->
					<div class="row" style="margin-top: 30px;">
					    <div class="col-md-12">
					        <h4>Review Statistics by Stylist:</h4>
					    </div>
					    <?php
					    $statsQuery = mysqli_query($con, "SELECT ts.StylistName, 
					                                      COUNT(tr.ID) as total_reviews,
					                                      AVG(tr.Rating) as avg_rating,
					                                      SUM(CASE WHEN tr.Status='Approved' THEN 1 ELSE 0 END) as approved,
					                                      SUM(CASE WHEN tr.Status='Pending' THEN 1 ELSE 0 END) as pending,
					                                      SUM(CASE WHEN tr.Status='Rejected' THEN 1 ELSE 0 END) as rejected
					                                      FROM tblstylist ts
					                                      LEFT JOIN tblstylist_reviews tr ON ts.ID = tr.StylistID
					                                      GROUP BY ts.ID, ts.StylistName
					                                      ORDER BY total_reviews DESC");
					    
					    while($stat = mysqli_fetch_array($statsQuery)) {
					    ?>
					    <div class="col-md-6" style="margin-bottom: 20px;">
					        <div class="panel panel-primary">
					            <div class="panel-heading">
					                <h4 class="panel-title"><?php echo $stat['StylistName'];?></h4>
					            </div>
					            <div class="panel-body">
					                <p><strong>Total Reviews:</strong> <?php echo $stat['total_reviews'];?></p>
					                <p><strong>Average Rating:</strong> <?php echo $stat['avg_rating'] ? round($stat['avg_rating'], 1) : 'N/A';?> / 5
					                    <?php if($stat['avg_rating']) { ?>
					                        <span class="star-display">
					                            <?php
					                            for($i = 1; $i <= 5; $i++) {
					                                if($i <= round($stat['avg_rating'])) {
					                                    echo '<i class="fa fa-star"></i>';
					                                } else {
					                                    echo '<i class="fa fa-star-o"></i>';
					                                }
					                            }
					                            ?>
					                        </span>
					                    <?php } ?>
					                </p>
					                <p>
					                    <span class="status-badge status-approved">Visible: <?php echo $stat['approved'];?></span>
					                    <span class="status-badge status-pending">Pending: <?php echo $stat['pending'];?></span>
					                    <span class="status-badge status-rejected">Hidden: <?php echo $stat['rejected'];?></span>
					                </p>
					            </div>
					        </div>
					    </div>
					    <?php } ?>
					</div>
				</div>
			</div>
		</div>
		<!--footer-->
		 <?php include_once('includes/footer.php');?>
        <!--//footer-->
	</div>
	<!-- Classie -->
		<script src="js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.js"> </script>
</body>
</html>
<?php } ?>

