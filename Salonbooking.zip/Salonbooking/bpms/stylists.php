<?php 
session_start();
error_reporting(0);
include('includes/dbconnection.php');

// Handle review submission
if (isset($_POST['submit_review'])) {
    if (strlen($_SESSION['bpmsuid']) == 0) {
        echo '<script>alert("Please login to submit a review"); window.location.href="login.php";</script>';
    } else {
        $userid = $_SESSION['bpmsuid'];
        $stylistid = $_POST['stylist_id'];
        $rating = $_POST['rating'];
        $review = $_POST['review'];
        
        // Check if user already reviewed this stylist
        $checkQuery = mysqli_query($con, "SELECT ID FROM tblstylist_reviews WHERE StylistID='$stylistid' AND UserID='$userid'");
        
        if(mysqli_num_rows($checkQuery) > 0) {
            // Update existing review
            $updateQuery = mysqli_query($con, "UPDATE tblstylist_reviews SET Rating='$rating', Review='$review', ReviewDate=NOW() WHERE StylistID='$stylistid' AND UserID='$userid'");
            if ($updateQuery) {
                echo '<script>alert("Your review has been updated successfully!")</script>';
            }
        } else {
            // Insert new review
            $insertQuery = mysqli_query($con, "INSERT INTO tblstylist_reviews(StylistID, UserID, Rating, Review) VALUES('$stylistid', '$userid', '$rating', '$review')");
            if ($insertQuery) {
                echo '<script>alert("Thank you for your review!")</script>';
            }
        }
    }
}
?>
<!doctype html>
<html lang="en">
  <head>
    <title>Salon Booking System | Our Stylists</title>

    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:400,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
    
    <style>
        /* Star Rating Display */
        .star-rating {
            font-size: 24px;
            color: #ddd;
            display: inline-block;
        }
        .star-rating .filled {
            color: #ffc107;
        }
        
        /* Stylist Card Styling */
        .stylist-card {
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .stylist-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .stylist-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #f0f0f0;
            margin-bottom: 15px;
        }
        .stylist-info h4 {
            color: #333;
            margin-bottom: 10px;
        }
        .stylist-info p {
            color: #666;
            margin-bottom: 8px;
        }
        .average-rating {
            display: inline-block;
            margin-left: 10px;
            color: #666;
            font-size: 16px;
        }
        
        /* Review Section */
        .review-section {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
        }
        .review-item {
            padding: 15px;
            background: #f9f9f9;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        .review-item .reviewer-name {
            font-weight: bold;
            color: #333;
        }
        .review-item .review-date {
            font-size: 12px;
            color: #999;
        }
        .review-item .review-text {
            margin-top: 8px;
            color: #555;
        }
        
        /* Review Form Styling */
        .review-form {
            background: #f0f7ff;
            padding: 15px 20px;
            border-radius: 8px;
            margin-top: 15px;
            border: 1px solid #d0e7ff;
        }
        .review-form h5 {
            font-size: 16px;
            margin-bottom: 12px;
            color: #333;
        }
        .review-form .form-group {
            margin-bottom: 12px;
        }
        .review-form label {
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 6px;
            color: #555;
        }
        .review-form textarea {
            font-size: 13px;
            resize: vertical;
            min-height: 70px;
        }
        .review-form .btn {
            padding: 8px 20px;
            font-size: 14px;
            margin-top: 5px;
        }
        
        /* Interactive Star Rating for Form */
        .star-rating-input {
            font-size: 30px;
            direction: rtl;
            display: inline-block;
        }
        .star-rating-input input[type="radio"] {
            display: none;
        }
        .star-rating-input label {
            color: #ddd;
            cursor: pointer;
            transition: color 0.2s;
        }
        .star-rating-input input[type="radio"]:checked ~ label,
        .star-rating-input label:hover,
        .star-rating-input label:hover ~ label {
            color: #ffc107;
        }
        
        /* Stats Badge */
        .stats-badge {
            display: inline-block;
            background: #e3f2fd;
            padding: 5px 15px;
            border-radius: 20px;
            margin: 5px;
            font-size: 14px;
            color: #1976d2;
        }
    </style>
  </head>
  <body id="home">
<?php include_once('includes/header.php');?>

<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script>
$(function () {
  $('.navbar-toggler').click(function () {
    $('body').toggleClass('noscroll');
  })
});
</script>

<!-- breadcrumbs -->
<section class="w3l-inner-banner-main">
    <div class="about-inner contact" style="background: url('https://images.pexels.com/photos/3065171/pexels-photo-3065171.jpeg?auto=compress&cs=tinysrgb&w=1200') no-repeat center center; background-size: cover;">
        <div class="container">   
            <div class="main-titles-head text-center">
                <h3 class="header-name">Our Professional Stylists</h3>
                <p class="tiltle-para">Meet our talented team and see what our customers say about them</p>
            </div>
        </div>
    </div>
    <div class="breadcrumbs-sub">
        <div class="container">   
            <ul class="breadcrumbs-custom-path">
                <li class="right-side propClone"><a href="index.php" class="">Home <span class="fa fa-angle-right" aria-hidden="true"></span></a></li>
                <li class="active">Stylists</li>
            </ul>
        </div>
    </div>
</section>
<!-- breadcrumbs //-->

<section class="w3l-contact-info-main" id="contact">
    <div class="contact-sec">
        <div class="container">
            <?php
            $query = mysqli_query($con, "SELECT * FROM tblstylist ORDER BY ID DESC");
            $count = mysqli_num_rows($query);
            
            if($count > 0) {
                while($row = mysqli_fetch_array($query)) {
                    $stylistID = $row['ID'];
                    
                    // Calculate average rating
                    $ratingQuery = mysqli_query($con, "SELECT AVG(Rating) as avg_rating, COUNT(*) as total_reviews FROM tblstylist_reviews WHERE StylistID='$stylistID' AND Status='Approved'");
                    $ratingData = mysqli_fetch_array($ratingQuery);
                    $avgRating = round($ratingData['avg_rating'], 1);
                    $totalReviews = $ratingData['total_reviews'];
                    
                    // Get reviews for this stylist
                    $reviewsQuery = mysqli_query($con, "SELECT tr.*, tu.FirstName, tu.LastName FROM tblstylist_reviews tr JOIN tbluser tu ON tr.UserID=tu.ID WHERE tr.StylistID='$stylistID' AND tr.Status='Approved' ORDER BY tr.ReviewDate DESC LIMIT 5");
            ?>
            
            <div class="stylist-card">
                <div class="row">
                    <div class="col-md-3 text-center">
                        <?php if(!empty($row['Image'])) { ?>
                            <img src="admin/images/<?php echo $row['Image']; ?>" alt="<?php echo $row['StylistName']; ?>" class="stylist-image" onerror="this.src='assets/images/t1.jpg'">
                        <?php } else { ?>
                            <img src="assets/images/t1.jpg" alt="<?php echo $row['StylistName']; ?>" class="stylist-image">
                        <?php } ?>
                        
                        <div class="star-rating">
                            <?php
                            for($i = 1; $i <= 5; $i++) {
                                if($i <= $avgRating) {
                                    echo '<span class="fa fa-star filled"></span>';
                                } else {
                                    echo '<span class="fa fa-star"></span>';
                                }
                            }
                            ?>
                        </div>
                        <div class="average-rating">
                            <?php echo $avgRating > 0 ? $avgRating : 'No ratings yet'; ?> 
                            <?php if($totalReviews > 0) echo "($totalReviews reviews)"; ?>
                        </div>
                    </div>
                    
                    <div class="col-md-9">
                        <div class="stylist-info">
                            <h4><?php echo $row['StylistName']; ?></h4>
                            <p><strong>Contact:</strong> <?php echo $row['MobileNumber']; ?></p>
                            
                            <?php if($totalReviews > 0) { ?>
                                <div class="stats-badge">
                                    <i class="fa fa-star"></i> <?php echo $totalReviews; ?> Customer Reviews
                                </div>
                            <?php } ?>
                            
                            <!-- Recent Reviews -->
                            <?php if(mysqli_num_rows($reviewsQuery) > 0) { ?>
                                <div class="review-section">
                                    <h5>Recent Reviews:</h5>
                                    <?php while($review = mysqli_fetch_array($reviewsQuery)) { ?>
                                        <div class="review-item">
                                            <div class="reviewer-name">
                                                <?php echo $review['FirstName'] . ' ' . substr($review['LastName'], 0, 1); ?>.
                                                <div class="star-rating" style="font-size: 16px; margin-left: 10px;">
                                                    <?php
                                                    for($i = 1; $i <= 5; $i++) {
                                                        if($i <= $review['Rating']) {
                                                            echo '<span class="fa fa-star filled"></span>';
                                                        } else {
                                                            echo '<span class="fa fa-star"></span>';
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                                <span class="review-date"><?php echo date('M d, Y', strtotime($review['ReviewDate'])); ?></span>
                                            </div>
                                            <?php if($review['Review']) { ?>
                                                <div class="review-text"><?php echo htmlspecialchars($review['Review']); ?></div>
                                            <?php } ?>
                                        </div>
                                    <?php } ?>
                                </div>
                            <?php } ?>
                            
                            <!-- Review Form -->
                            <?php if(isset($_SESSION['bpmsuid'])) { 
                                // Check if user already reviewed
                                $userid = $_SESSION['bpmsuid'];
                                $checkReview = mysqli_query($con, "SELECT * FROM tblstylist_reviews WHERE StylistID='$stylistID' AND UserID='$userid'");
                                $existingReview = mysqli_fetch_array($checkReview);
                            ?>
                                <div class="review-form">
                                    <h5><?php echo $existingReview ? 'Update Your Review' : 'Leave a Review'; ?></h5>
                                    <form method="post">
                                        <input type="hidden" name="stylist_id" value="<?php echo $stylistID; ?>">
                                        
                                        <div class="form-group">
                                            <label>Your Rating:</label><br>
                                            <div class="star-rating-input">
                                                <input type="radio" name="rating" value="5" id="star5-<?php echo $stylistID; ?>" <?php if($existingReview && $existingReview['Rating']==5) echo 'checked'; ?> required>
                                                <label for="star5-<?php echo $stylistID; ?>" class="fa fa-star"></label>
                                                
                                                <input type="radio" name="rating" value="4" id="star4-<?php echo $stylistID; ?>" <?php if($existingReview && $existingReview['Rating']==4) echo 'checked'; ?>>
                                                <label for="star4-<?php echo $stylistID; ?>" class="fa fa-star"></label>
                                                
                                                <input type="radio" name="rating" value="3" id="star3-<?php echo $stylistID; ?>" <?php if($existingReview && $existingReview['Rating']==3) echo 'checked'; ?>>
                                                <label for="star3-<?php echo $stylistID; ?>" class="fa fa-star"></label>
                                                
                                                <input type="radio" name="rating" value="2" id="star2-<?php echo $stylistID; ?>" <?php if($existingReview && $existingReview['Rating']==2) echo 'checked'; ?>>
                                                <label for="star2-<?php echo $stylistID; ?>" class="fa fa-star"></label>
                                                
                                                <input type="radio" name="rating" value="1" id="star1-<?php echo $stylistID; ?>" <?php if($existingReview && $existingReview['Rating']==1) echo 'checked'; ?>>
                                                <label for="star1-<?php echo $stylistID; ?>" class="fa fa-star"></label>
                                            </div>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Your Review (Optional):</label>
                                            <textarea name="review" class="form-control" rows="2" placeholder="Share your experience..." style="font-size: 13px;"><?php if($existingReview) echo htmlspecialchars($existingReview['Review']); ?></textarea>
                                        </div>
                                        
                                        <button type="submit" name="submit_review" class="btn btn-primary">
                                            <?php echo $existingReview ? 'Update Review' : 'Submit Review'; ?>
                                        </button>
                                    </form>
                                </div>
                            <?php } else { ?>
                                <div class="review-form">
                                    <p><a href="login.php">Login</a> to leave a review for this stylist</p>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php 
                }
            } else { ?>
                <div class="alert alert-info">
                    <p>No stylists available at the moment. Please check back later!</p>
                </div>
            <?php } ?>
        </div>
    </div>
</section>

<?php include_once('includes/footer.php');?>

<!-- move top -->
<button onclick="topFunction()" id="movetop" title="Go to top">
	<span class="fa fa-long-arrow-up"></span>
</button>
<script>
	window.onscroll = function () {
		scrollFunction()
	};

	function scrollFunction() {
		if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
			document.getElementById("movetop").style.display = "block";
		} else {
			document.getElementById("movetop").style.display = "none";
		}
	}

	function topFunction() {
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
	}
</script>
</body>
</html>

