# 🌟 SALUT - Salon Booking Management System

A comprehensive salon appointment booking and management system with smart scheduling, payment integration, and customer reviews.

---

## 🚀 Quick Start

### 1. Database Setup
```bash
# Import SQL files in phpMyAdmin in this order:
1. SQL File/bpmsdb
2. SQL File/add_service_duration.sql  
3. SQL File/stylist_reviews_table.sql
```

### 2. Configure Database
Edit these files with your database credentials:
- `includes/dbconnection.php`
- `admin/includes/dbconnection.php`

### 3. Access System
- **Customer Portal**: `http://localhost/Salonbooking/bpms/`
- **Admin Panel**: `http://localhost/Salonbooking/bpms/admin/`

---

## ✨ Key Features

### For Customers
- 📅 Book appointments with multiple services
- ⭐ Rate and review stylists
- 💳 Pay invoices online (Stripe)
- 📧 Receive email notifications
- 📊 View booking history

### For Admins
- 🎛️ Manage bookings, services, stylists
- 📈 Generate sales reports
- 💰 Track payments and invoices
- 🔍 Monitor customer reviews
- 📧 Automated email notifications

---

## 📚 Documentation

- **Complete Guide**: `SYSTEM_DOCUMENTATION.md` (All features explained)
- **Quick Setup**: See above
- **Troubleshooting**: Check SYSTEM_DOCUMENTATION.md

---

## 🛠️ Tech Stack

- **Backend**: PHP, MySQL
- **Frontend**: HTML, CSS, JavaScript, Bootstrap
- **Payment**: Stripe
- **Email**: SMTP (Gmail recommended)

---

## 📋 System Requirements

- PHP 7.0 or higher
- MySQL 5.7 or higher
- Apache/Nginx server
- Composer (for Stripe library)

---

## 🎯 Main Components

1. **Smart Booking System**: Time slots based on service duration
2. **Review System**: Customer ratings for stylists
3. **Payment Integration**: Stripe checkout
4. **Email Notifications**: Automated booking confirmations
5. **Admin Dashboard**: Dark theme, professional UI

---

## 📞 Support

For detailed documentation, see `SYSTEM_DOCUMENTATION.md`

---

**Version**: 2.0  
**Status**: ✅ Production Ready  
**Last Updated**: 2025

