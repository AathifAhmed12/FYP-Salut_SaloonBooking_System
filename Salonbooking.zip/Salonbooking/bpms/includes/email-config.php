<?php
/**
 * Email Configuration and Helper Functions
 * 
 * This file contains email settings and functions to send notifications
 * for various events in the salon booking system.
 */

// ============================================
// EMAIL CONFIGURATION
// ============================================

// Email settings - Update these with your actual email details
define('SYSTEM_EMAIL', 'salutowner@gmail.com');  // Your salon's email address
define('SYSTEM_NAME', 'SALUT SBS');  // Your salon name
define('ADMIN_EMAIL', 'salutowner@gmail.com');  // Admin email to receive notifications

// For production, you'll want to use a proper email service like:
// - Gmail SMTP
// - SendGrid
// - Mailgun
// - AWS SES
// For now, this uses PHP's built-in mail() function


// ============================================
// EMAIL HELPER FUNCTION
// ============================================

/**
 * Send Email Function
 * 
 * @param string $to - Recipient email address
 * @param string $subject - Email subject
 * @param string $message - Email body (HTML format)
 * @param string $fromEmail - Sender email (optional)
 * @param string $fromName - Sender name (optional)
 * @return bool - True if email sent successfully, false otherwise
 */
function sendEmail($to, $subject, $message, $fromEmail = SYSTEM_EMAIL, $fromName = SYSTEM_NAME) {
    // Email headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: " . $fromName . " <" . $fromEmail . ">" . "\r\n";
    $headers .= "Reply-To: " . $fromEmail . "\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();
    
    // Send email
    $sent = mail($to, $subject, $message, $headers);
    
    // Log email attempt (optional - for debugging)
    if (!$sent) {
        error_log("Email failed to send to: " . $to . " | Subject: " . $subject);
    }
    
    return $sent;
}

/**
 * Send Email Asynchronously (Non-blocking)
 * This function sends email in the background without blocking page response
 * 
 * @param string $to - Recipient email address
 * @param string $subject - Email subject
 * @param string $message - Email body (HTML format)
 * @param string $fromEmail - Sender email (optional)
 * @param string $fromName - Sender name (optional)
 * @return void - Returns immediately without waiting
 */
function sendEmailAsync($to, $subject, $message, $fromEmail = SYSTEM_EMAIL, $fromName = SYSTEM_NAME) {
    // Always use shutdown function to send email after page output is complete
    // This prevents "headers already sent" errors
    register_shutdown_function(function() use ($to, $subject, $message, $fromEmail, $fromName) {
        sendEmail($to, $subject, $message, $fromEmail, $fromName);
    });
    
    // If fastcgi_finish_request is available, finish the request immediately
    // This allows the page to complete while email sends in background
    if (function_exists('fastcgi_finish_request')) {
        // Only flush output buffer if it exists and headers haven't been sent
        if (!headers_sent() && ob_get_level() > 0) {
            ob_end_flush();
        }
        fastcgi_finish_request();
    }
    // If fastcgi_finish_request is not available, email will still be sent
    // via shutdown function after page completes, but page will wait for it
}


// ============================================
// EMAIL TEMPLATE WRAPPER
// ============================================

/**
 * Email Template Wrapper
 * 
 * Wraps email content in a professional HTML template
 * 
 * @param string $content - Main email content
 * @param string $title - Email title
 * @return string - Complete HTML email
 */
function emailTemplate($content, $title = '') {
    $template = '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>' . htmlspecialchars($title) . '</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
                margin: 0;
                padding: 0;
                background-color: #f4f4f4;
            }
            .email-container {
                max-width: 600px;
                margin: 20px auto;
                background-color: #ffffff;
                border-radius: 8px;
                overflow: hidden;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .email-header {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #ffffff;
                padding: 30px;
                text-align: center;
            }
            .email-header h1 {
                margin: 0;
                font-size: 24px;
                font-weight: 600;
            }
            .email-body {
                padding: 30px;
            }
            .email-body h2 {
                color: #667eea;
                font-size: 20px;
                margin-top: 0;
            }
            .info-box {
                background-color: #f8f9fa;
                border-left: 4px solid #667eea;
                padding: 15px;
                margin: 20px 0;
            }
            .info-box strong {
                color: #667eea;
            }
            .button {
                display: inline-block;
                padding: 12px 30px;
                background-color: #667eea;
                color: #ffffff !important;
                text-decoration: none;
                border-radius: 5px;
                margin: 20px 0;
                font-weight: 600;
            }
            .button:hover {
                background-color: #5568d3;
            }
            .email-footer {
                background-color: #f8f9fa;
                padding: 20px;
                text-align: center;
                font-size: 12px;
                color: #6c757d;
            }
            .divider {
                border: 0;
                height: 1px;
                background: #e9ecef;
                margin: 20px 0;
            }
            .status-badge {
                display: inline-block;
                padding: 5px 15px;
                border-radius: 20px;
                font-size: 14px;
                font-weight: 600;
                margin: 10px 0;
            }
            .status-pending {
                background-color: #fff3cd;
                color: #856404;
            }
            .status-accepted {
                background-color: #d4edda;
                color: #155724;
            }
            .status-rejected {
                background-color: #f8d7da;
                color: #721c24;
            }
        </style>
    </head>
    <body>
        <div class="email-container">
            <div class="email-header">
                <h1>💇 ' . SYSTEM_NAME . '</h1>
            </div>
            <div class="email-body">
                ' . $content . '
            </div>
            <div class="email-footer">
                <p><strong>' . SYSTEM_NAME . '</strong></p>
                <p>This is an automated email. Please do not reply to this email.</p>
                <p>If you have any questions, please contact us at <a href="mailto:' . SYSTEM_EMAIL . '">' . SYSTEM_EMAIL . '</a></p>
            </div>
        </div>
    </body>
    </html>
    ';
    
    return $template;
}


// ============================================
// NOTIFICATION EMAIL FUNCTIONS
// ============================================

/**
 * Send Booking Confirmation Email to Customer
 * 
 * @param array $bookingData - Booking details
 * @return bool - True if sent successfully
 */
function sendBookingConfirmationEmail($bookingData) {
    $to = $bookingData['customerEmail'];
    $subject = "Appointment Booking Confirmation - " . $bookingData['appointmentNumber'];
    
    $content = '
        <h2>Thank You for Your Booking!</h2>
        <p>Dear <strong>' . htmlspecialchars($bookingData['customerName']) . '</strong>,</p>
        <p>We have received your appointment request. Your booking is currently pending confirmation from our admin.</p>
        
        <div class="info-box">
            <strong>Appointment Number:</strong> ' . htmlspecialchars($bookingData['appointmentNumber']) . '<br>
            <strong>Date:</strong> ' . date('F j, Y', strtotime($bookingData['appointmentDate'])) . '<br>
            <strong>Time:</strong> ' . date('g:i A', strtotime($bookingData['appointmentTime'])) . '<br>
            <strong>Services:</strong> ' . htmlspecialchars($bookingData['services']) . '<br>
            <strong>Stylist:</strong> ' . htmlspecialchars($bookingData['stylist']) . '<br>
            <strong>Status:</strong> <span class="status-badge status-pending">Pending Confirmation</span>
        </div>
        
        <p>You will receive another email once your appointment is confirmed by our admin.</p>
        <p>Thank you for choosing our salon!</p>
    ';
    
    $message = emailTemplate($content, 'Booking Confirmation');
    return sendEmail($to, $subject, $message);
}

/**
 * Send Booking Confirmation Email Async (Non-blocking)
 */
function sendBookingConfirmationEmailAsync($bookingData) {
    $to = $bookingData['customerEmail'];
    $subject = "Appointment Booking Confirmation - " . $bookingData['appointmentNumber'];
    
    $content = '
        <h2>Thank You for Your Booking!</h2>
        <p>Dear <strong>' . htmlspecialchars($bookingData['customerName']) . '</strong>,</p>
        <p>We have received your appointment request. Your booking is currently pending confirmation from our admin.</p>
        
        <div class="info-box">
            <strong>Appointment Number:</strong> ' . htmlspecialchars($bookingData['appointmentNumber']) . '<br>
            <strong>Date:</strong> ' . date('F j, Y', strtotime($bookingData['appointmentDate'])) . '<br>
            <strong>Time:</strong> ' . date('g:i A', strtotime($bookingData['appointmentTime'])) . '<br>
            <strong>Services:</strong> ' . htmlspecialchars($bookingData['services']) . '<br>
            <strong>Stylist:</strong> ' . htmlspecialchars($bookingData['stylist']) . '<br>
            <strong>Status:</strong> <span class="status-badge status-pending">Pending Confirmation</span>
        </div>
        
        <p>You will receive another email once your appointment is confirmed by our admin.</p>
        <p>Thank you for choosing our salon!</p>
    ';
    
    $message = emailTemplate($content, 'Booking Confirmation');
    sendEmailAsync($to, $subject, $message);
}

/**
 * Send New Booking Notification to Admin Async (Non-blocking)
 */
function sendNewBookingNotificationToAdminAsync($bookingData) {
    $to = ADMIN_EMAIL;
    $subject = "New Appointment Booking - " . $bookingData['appointmentNumber'];
    
    $content = '
        <h2>New Appointment Request</h2>
        <p>A new appointment has been booked and requires your review.</p>
        
        <div class="info-box">
            <strong>Appointment Number:</strong> ' . htmlspecialchars($bookingData['appointmentNumber']) . '<br>
            <strong>Customer Name:</strong> ' . htmlspecialchars($bookingData['customerName']) . '<br>
            <strong>Email:</strong> ' . htmlspecialchars($bookingData['customerEmail']) . '<br>
            <strong>Phone:</strong> ' . htmlspecialchars($bookingData['customerPhone']) . '<br>
            <strong>Date:</strong> ' . date('F j, Y', strtotime($bookingData['appointmentDate'])) . '<br>
            <strong>Time:</strong> ' . date('g:i A', strtotime($bookingData['appointmentTime'])) . '<br>
            <strong>Services:</strong> ' . htmlspecialchars($bookingData['services']) . '<br>
            <strong>Stylist:</strong> ' . htmlspecialchars($bookingData['stylist']) . '<br>
            <strong>Message:</strong> ' . htmlspecialchars($bookingData['message']) . '
        </div>
        
        <p style="text-align: center;">
            <a href="' . getBaseUrl() . '/admin/new-appointment.php" class="button">Review Appointment</a>
        </p>
        
        <p>Please review and accept or decline this appointment as soon as possible.</p>
    ';
    
    $message = emailTemplate($content, 'New Appointment Notification');
    sendEmailAsync($to, $subject, $message);
}

/**
 * Send Appointment Accepted Email Async (Non-blocking)
 */
function sendAppointmentAcceptedEmailAsync($bookingData) {
    $to = $bookingData['customerEmail'];
    $subject = "Appointment Confirmed - " . $bookingData['appointmentNumber'];
    
    $content = '
        <h2>✅ Your Appointment Has Been Confirmed!</h2>
        <p>Dear <strong>' . htmlspecialchars($bookingData['customerName']) . '</strong>,</p>
        <p>Great news! Your appointment has been confirmed by our admin.</p>
        
        <div class="info-box">
            <strong>Appointment Number:</strong> ' . htmlspecialchars($bookingData['appointmentNumber']) . '<br>
            <strong>Date:</strong> ' . date('F j, Y', strtotime($bookingData['appointmentDate'])) . '<br>
            <strong>Time:</strong> ' . date('g:i A', strtotime($bookingData['appointmentTime'])) . '<br>
            <strong>Services:</strong> ' . htmlspecialchars($bookingData['services']) . '<br>
            <strong>Stylist:</strong> ' . htmlspecialchars($bookingData['stylist']) . '<br>
            <strong>Status:</strong> <span class="status-badge status-accepted">Confirmed</span>
        </div>
        
        <p><strong>Please arrive 5-10 minutes before your scheduled time.</strong></p>
        <p>We look forward to serving you!</p>
        
        <p style="text-align: center;">
            <a href="' . getBaseUrl() . '/booking-history.php" class="button">View My Bookings</a>
        </p>
    ';
    
    $message = emailTemplate($content, 'Appointment Confirmed');
    sendEmailAsync($to, $subject, $message);
}

/**
 * Send Appointment Rejected Email Async (Non-blocking)
 */
function sendAppointmentRejectedEmailAsync($bookingData) {
    $to = $bookingData['customerEmail'];
    $subject = "Appointment Update - " . $bookingData['appointmentNumber'];
    
    $content = '
        <h2>Appointment Status Update</h2>
        <p>Dear <strong>' . htmlspecialchars($bookingData['customerName']) . '</strong>,</p>
        <p>We regret to inform you that your appointment request could not be confirmed.</p>
        
        <div class="info-box">
            <strong>Appointment Number:</strong> ' . htmlspecialchars($bookingData['appointmentNumber']) . '<br>
            <strong>Date:</strong> ' . date('F j, Y', strtotime($bookingData['appointmentDate'])) . '<br>
            <strong>Time:</strong> ' . date('g:i A', strtotime($bookingData['appointmentTime'])) . '<br>
            <strong>Services:</strong> ' . htmlspecialchars($bookingData['services']) . '<br>
            <strong>Status:</strong> <span class="status-badge status-rejected">Declined</span>
        </div>
        
        ' . (isset($bookingData['remark']) && !empty($bookingData['remark']) ? 
            '<p><strong>Reason:</strong> ' . htmlspecialchars($bookingData['remark']) . '</p>' : '') . '
        
        <p>We apologize for any inconvenience. Please feel free to book another appointment or contact us for assistance.</p>
        
        <p style="text-align: center;">
            <a href="' . getBaseUrl() . '/book-appointment.php" class="button">Book Another Appointment</a>
        </p>
    ';
    
    $message = emailTemplate($content, 'Appointment Update');
    sendEmailAsync($to, $subject, $message);
}

/**
 * Send Invoice Notification Email Async (Non-blocking)
 */
function sendInvoiceNotificationEmailAsync($invoiceData) {
    $to = $invoiceData['customerEmail'];
    $subject = "Invoice for Your Appointment - Invoice #" . $invoiceData['invoiceNumber'];
    
    $content = '
        <h2>Your Invoice is Ready</h2>
        <p>Dear <strong>' . htmlspecialchars($invoiceData['customerName']) . '</strong>,</p>
        <p>Your invoice has been generated for your recent appointment.</p>
        
        <div class="info-box">
            <strong>Invoice Number:</strong> ' . htmlspecialchars($invoiceData['invoiceNumber']) . '<br>
            <strong>Appointment Number:</strong> ' . htmlspecialchars($invoiceData['appointmentNumber']) . '<br>
            <strong>Services:</strong> ' . htmlspecialchars($invoiceData['services']) . '<br>
            <strong>Total Amount:</strong> <span style="font-size: 18px; color: #28a745;">Rs. ' . number_format($invoiceData['totalAmount'], 2) . '</span>
        </div>
        
        <p>You can view and pay your invoice online using our secure payment system.</p>
        
        <p style="text-align: center;">
            <a href="' . getBaseUrl() . '/view-invoice.php?invoiceid=' . $invoiceData['invoiceNumber'] . '" class="button">View & Pay Invoice</a>
        </p>
        
        <p>Thank you for your business!</p>
    ';
    
    $message = emailTemplate($content, 'Invoice Ready');
    sendEmailAsync($to, $subject, $message);
}

/**
 * Send Payment Confirmation Email Async (Non-blocking)
 */
function sendPaymentConfirmationEmailAsync($paymentData) {
    $to = $paymentData['customerEmail'];
    $subject = "Payment Received - Invoice #" . $paymentData['invoiceNumber'];
    
    $content = '
        <h2>✅ Payment Received Successfully!</h2>
        <p>Dear <strong>' . htmlspecialchars($paymentData['customerName']) . '</strong>,</p>
        <p>Thank you! We have received your payment.</p>
        
        <div class="info-box">
            <strong>Invoice Number:</strong> ' . htmlspecialchars($paymentData['invoiceNumber']) . '<br>
            <strong>Amount Paid:</strong> <span style="font-size: 18px; color: #28a745;">Rs. ' . number_format($paymentData['amount'], 2) . '</span><br>
            <strong>Payment Method:</strong> ' . htmlspecialchars($paymentData['paymentMethod']) . '<br>
            <strong>Transaction ID:</strong> ' . htmlspecialchars($paymentData['transactionID']) . '<br>
            <strong>Payment Date:</strong> ' . date('F j, Y - g:i A') . '
        </div>
        
        <p>Your payment has been processed successfully. You can view your receipt anytime by clicking the button below.</p>
        
        <p style="text-align: center;">
            <a href="' . getBaseUrl() . '/view-invoice.php?invoiceid=' . $paymentData['invoiceNumber'] . '" class="button">View Receipt</a>
        </p>
        
        <p>We appreciate your business and look forward to serving you again!</p>
    ';
    
    $message = emailTemplate($content, 'Payment Confirmation');
    sendEmailAsync($to, $subject, $message);
}


/**
 * Send New Booking Notification to Admin
 * 
 * @param array $bookingData - Booking details
 * @return bool - True if sent successfully
 */
function sendNewBookingNotificationToAdmin($bookingData) {
    $to = ADMIN_EMAIL;
    $subject = "New Appointment Booking - " . $bookingData['appointmentNumber'];
    
    $content = '
        <h2>New Appointment Request</h2>
        <p>A new appointment has been booked and requires your review.</p>
        
        <div class="info-box">
            <strong>Appointment Number:</strong> ' . htmlspecialchars($bookingData['appointmentNumber']) . '<br>
            <strong>Customer Name:</strong> ' . htmlspecialchars($bookingData['customerName']) . '<br>
            <strong>Email:</strong> ' . htmlspecialchars($bookingData['customerEmail']) . '<br>
            <strong>Phone:</strong> ' . htmlspecialchars($bookingData['customerPhone']) . '<br>
            <strong>Date:</strong> ' . date('F j, Y', strtotime($bookingData['appointmentDate'])) . '<br>
            <strong>Time:</strong> ' . date('g:i A', strtotime($bookingData['appointmentTime'])) . '<br>
            <strong>Services:</strong> ' . htmlspecialchars($bookingData['services']) . '<br>
            <strong>Stylist:</strong> ' . htmlspecialchars($bookingData['stylist']) . '<br>
            <strong>Message:</strong> ' . htmlspecialchars($bookingData['message']) . '
        </div>
        
        <p style="text-align: center;">
            <a href="' . getBaseUrl() . '/admin/new-appointment.php" class="button">Review Appointment</a>
        </p>
        
        <p>Please review and accept or decline this appointment as soon as possible.</p>
    ';
    
    $message = emailTemplate($content, 'New Appointment Notification');
    return sendEmail($to, $subject, $message);
}


/**
 * Send Appointment Accepted Email to Customer
 * 
 * @param array $bookingData - Booking details
 * @return bool - True if sent successfully
 */
function sendAppointmentAcceptedEmail($bookingData) {
    $to = $bookingData['customerEmail'];
    $subject = "Appointment Confirmed - " . $bookingData['appointmentNumber'];
    
    $content = '
        <h2>✅ Your Appointment Has Been Confirmed!</h2>
        <p>Dear <strong>' . htmlspecialchars($bookingData['customerName']) . '</strong>,</p>
        <p>Great news! Your appointment has been confirmed by our admin.</p>
        
        <div class="info-box">
            <strong>Appointment Number:</strong> ' . htmlspecialchars($bookingData['appointmentNumber']) . '<br>
            <strong>Date:</strong> ' . date('F j, Y', strtotime($bookingData['appointmentDate'])) . '<br>
            <strong>Time:</strong> ' . date('g:i A', strtotime($bookingData['appointmentTime'])) . '<br>
            <strong>Services:</strong> ' . htmlspecialchars($bookingData['services']) . '<br>
            <strong>Stylist:</strong> ' . htmlspecialchars($bookingData['stylist']) . '<br>
            <strong>Status:</strong> <span class="status-badge status-accepted">Confirmed</span>
        </div>
        
        <p><strong>Please arrive 5-10 minutes before your scheduled time.</strong></p>
        <p>We look forward to serving you!</p>
        
        <p style="text-align: center;">
            <a href="' . getBaseUrl() . '/booking-history.php" class="button">View My Bookings</a>
        </p>
    ';
    
    $message = emailTemplate($content, 'Appointment Confirmed');
    return sendEmail($to, $subject, $message);
}


/**
 * Send Appointment Rejected Email to Customer
 * 
 * @param array $bookingData - Booking details
 * @return bool - True if sent successfully
 */
function sendAppointmentRejectedEmail($bookingData) {
    $to = $bookingData['customerEmail'];
    $subject = "Appointment Update - " . $bookingData['appointmentNumber'];
    
    $content = '
        <h2>Appointment Status Update</h2>
        <p>Dear <strong>' . htmlspecialchars($bookingData['customerName']) . '</strong>,</p>
        <p>We regret to inform you that your appointment request could not be confirmed.</p>
        
        <div class="info-box">
            <strong>Appointment Number:</strong> ' . htmlspecialchars($bookingData['appointmentNumber']) . '<br>
            <strong>Date:</strong> ' . date('F j, Y', strtotime($bookingData['appointmentDate'])) . '<br>
            <strong>Time:</strong> ' . date('g:i A', strtotime($bookingData['appointmentTime'])) . '<br>
            <strong>Services:</strong> ' . htmlspecialchars($bookingData['services']) . '<br>
            <strong>Status:</strong> <span class="status-badge status-rejected">Declined</span>
        </div>
        
        ' . (isset($bookingData['remark']) && !empty($bookingData['remark']) ? 
            '<p><strong>Reason:</strong> ' . htmlspecialchars($bookingData['remark']) . '</p>' : '') . '
        
        <p>We apologize for any inconvenience. Please feel free to book another appointment or contact us for assistance.</p>
        
        <p style="text-align: center;">
            <a href="' . getBaseUrl() . '/book-appointment.php" class="button">Book Another Appointment</a>
        </p>
    ';
    
    $message = emailTemplate($content, 'Appointment Update');
    return sendEmail($to, $subject, $message);
}


/**
 * Send Invoice Notification Email to Customer
 * 
 * @param array $invoiceData - Invoice details
 * @return bool - True if sent successfully
 */
function sendInvoiceNotificationEmail($invoiceData) {
    $to = $invoiceData['customerEmail'];
    $subject = "Invoice for Your Appointment - Invoice #" . $invoiceData['invoiceNumber'];
    
    $content = '
        <h2>Your Invoice is Ready</h2>
        <p>Dear <strong>' . htmlspecialchars($invoiceData['customerName']) . '</strong>,</p>
        <p>Your invoice has been generated for your recent appointment.</p>
        
        <div class="info-box">
            <strong>Invoice Number:</strong> ' . htmlspecialchars($invoiceData['invoiceNumber']) . '<br>
            <strong>Appointment Number:</strong> ' . htmlspecialchars($invoiceData['appointmentNumber']) . '<br>
            <strong>Services:</strong> ' . htmlspecialchars($invoiceData['services']) . '<br>
            <strong>Total Amount:</strong> <span style="font-size: 18px; color: #28a745;">Rs. ' . number_format($invoiceData['totalAmount'], 2) . '</span>
        </div>
        
        <p>You can view and pay your invoice online using our secure payment system.</p>
        
        <p style="text-align: center;">
            <a href="' . getBaseUrl() . '/view-invoice.php?invoiceid=' . $invoiceData['invoiceNumber'] . '" class="button">View & Pay Invoice</a>
        </p>
        
        <p>Thank you for your business!</p>
    ';
    
    $message = emailTemplate($content, 'Invoice Ready');
    return sendEmail($to, $subject, $message);
}


/**
 * Send Payment Confirmation Email to Customer
 * 
 * @param array $paymentData - Payment details
 * @return bool - True if sent successfully
 */
function sendPaymentConfirmationEmail($paymentData) {
    $to = $paymentData['customerEmail'];
    $subject = "Payment Received - Invoice #" . $paymentData['invoiceNumber'];
    
    $content = '
        <h2>✅ Payment Received Successfully!</h2>
        <p>Dear <strong>' . htmlspecialchars($paymentData['customerName']) . '</strong>,</p>
        <p>Thank you! We have received your payment.</p>
        
        <div class="info-box">
            <strong>Invoice Number:</strong> ' . htmlspecialchars($paymentData['invoiceNumber']) . '<br>
            <strong>Amount Paid:</strong> <span style="font-size: 18px; color: #28a745;">Rs. ' . number_format($paymentData['amount'], 2) . '</span><br>
            <strong>Payment Method:</strong> ' . htmlspecialchars($paymentData['paymentMethod']) . '<br>
            <strong>Transaction ID:</strong> ' . htmlspecialchars($paymentData['transactionID']) . '<br>
            <strong>Payment Date:</strong> ' . date('F j, Y - g:i A') . '
        </div>
        
        <p>Your payment has been processed successfully. You can view your receipt anytime by clicking the button below.</p>
        
        <p style="text-align: center;">
            <a href="' . getBaseUrl() . '/view-invoice.php?invoiceid=' . $paymentData['invoiceNumber'] . '" class="button">View Receipt</a>
        </p>
        
        <p>We appreciate your business and look forward to serving you again!</p>
    ';
    
    $message = emailTemplate($content, 'Payment Confirmation');
    return sendEmail($to, $subject, $message);
}


// ============================================
// HELPER FUNCTION
// ============================================

/**
 * Get Base URL of the application
 * 
 * @return string - Base URL
 */
function getBaseUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'];
    $path = dirname(dirname($script)); // Go up two levels from includes/
    return $protocol . '://' . $host . $path;
}

?>

