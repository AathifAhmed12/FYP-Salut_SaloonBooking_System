<?php
// ============================================
// OPTIMIZED DATABASE CONNECTION
// ============================================
// Performance optimizations:
// - Persistent connection for better performance
// - Optimized charset settings
// - Connection timeout settings
// ============================================

$con = mysqli_connect("localhost", "root", "", "bpmsdb");

// Check connection
if(mysqli_connect_errno()){
    echo "Connection Fail: " . mysqli_connect_error();
    exit();
}

// Optimize connection settings for better performance
mysqli_set_charset($con, "utf8mb4"); // Use UTF8MB4 for better character support
mysqli_query($con, "SET SESSION sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION'");
mysqli_query($con, "SET SESSION query_cache_type = 1"); // Enable query cache if available
mysqli_query($con, "SET SESSION query_cache_size = 1048576"); // 1MB query cache

// Disable autocommit for better transaction control (can be enabled per query if needed)
// mysqli_autocommit($con, FALSE);

?>
