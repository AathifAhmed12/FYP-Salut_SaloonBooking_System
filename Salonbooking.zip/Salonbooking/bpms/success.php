<?php
session_start();
include('includes/dbconnection.php');

// Include Stripe's PHP library
require '../vendor/autoload.php';

// Set your Stripe secret key
\Stripe\Stripe::setApiKey('sk_test_51QCdFlLrGzRaEuveCrzRu8TyHnCYfix77jbknTmfpXgeZHZwAGnrZ3AbFG0mReigcc05y766BKh6u5cce8bxdIBj00V1TEojwL');




?>
