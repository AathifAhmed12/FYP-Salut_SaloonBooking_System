<?php
/**
 * View Invoice Page
 * Displays invoice details and handles Stripe payment verification
 */

// Start session
session_start();

// Include database connection
include('includes/dbconnection.php');

// Load Stripe PHP library
require '../vendor/autoload.php';

// Set Stripe API Key
\Stripe\Stripe::setApiKey('sk_test_51QCdFlLrGzRaEuveCrzRu8TyHnCYfix77jbknTmfpXgeZHZwAGnrZ3AbFG0mReigcc05y766BKh6u5cce8bxdIBj00V1TEojwL');

// Initialize payment message variables
$paymentMessage = '';
$paymentStatus = '';
$showPaymentAlert = false;

// ==========================================
// STEP 1: Check if customer returned from Stripe payment
// ==========================================
if (isset($_GET['session_id']) && isset($_GET['invoiceid'])) {
    
    $sessionId = $_GET['session_id']; // Stripe session ID
    $invoiceId = intval($_GET['invoiceid']); // Invoice/Billing ID
    
    try {
        // Retrieve the payment session from Stripe to verify it
        $session = \Stripe\Checkout\Session::retrieve($sessionId);
        
        // Check if payment was successful
        if ($session && $session->payment_status === 'paid') {
            
            // Payment was successful! Extract payment details
            $amountPaid = $session->amount_total / 100; // Convert cents to rupees
            $transactionId = $session->payment_intent; // Unique transaction ID from Stripe
            $customerEmail = $session->customer_details->email; // Customer email
            $paymentMethod = 'Stripe (Card)';
            
            // ==========================================
            // STEP 2: Update payment status in database
            // ==========================================
            
            // First, check if payment record already exists to avoid duplicate updates
            $checkQuery = "SELECT PaymentStatus FROM tblinvoice WHERE BillingId = '$invoiceId' LIMIT 1";
            $checkResult = mysqli_query($con, $checkQuery);
            $currentStatus = mysqli_fetch_array($checkResult);
            
            if ($currentStatus && $currentStatus['PaymentStatus'] !== 'paid') {
                
                // Update the invoice table with payment status
                $updateInvoiceQuery = "UPDATE tblinvoice 
                                      SET PaymentStatus = 'paid' 
                                      WHERE BillingId = '$invoiceId'";
                
                if (mysqli_query($con, $updateInvoiceQuery)) {
                    
                    // Check if a payment record exists in tblpayments
                    $paymentCheckQuery = "SELECT PaymentID FROM tblpayments WHERE AppointmentNumber = '$invoiceId' LIMIT 1";
                    $paymentCheckResult = mysqli_query($con, $paymentCheckQuery);
                    
                    if (mysqli_num_rows($paymentCheckResult) > 0) {
                        // Update existing payment record
                        $updatePaymentQuery = "UPDATE tblpayments 
                                              SET PaymentStatus = 'Paid', 
                                                  TransactionID = '$transactionId', 
                                                  PaymentMethod = '$paymentMethod', 
                                                  PaymentDate = NOW(), 
                                                  Amount = '$amountPaid'
                                              WHERE AppointmentNumber = '$invoiceId'";
                        mysqli_query($con, $updatePaymentQuery);
                    } else {
                        // Insert new payment record
                        $insertPaymentQuery = "INSERT INTO tblpayments 
                                              (AppointmentNumber, PaymentStatus, TransactionID, PaymentMethod, PaymentDate, Amount) 
                                              VALUES 
                                              ('$invoiceId', 'Paid', '$transactionId', '$paymentMethod', NOW(), '$amountPaid')";
                        mysqli_query($con, $insertPaymentQuery);
                    }
                    
                    // ==========================================
                    // SEND PAYMENT CONFIRMATION EMAIL
                    // ==========================================
                    include('includes/email-config.php');
                    
                    // Get customer details
                    $customerQuery = mysqli_query($con, "SELECT DISTINCT tbluser.FirstName, tbluser.LastName, tbluser.Email 
                                                         FROM tblinvoice 
                                                         JOIN tbluser ON tblinvoice.Userid = tbluser.ID 
                                                         WHERE tblinvoice.BillingId='$invoiceId' LIMIT 1");
                    $customerData = mysqli_fetch_array($customerQuery);
                    
                    // Prepare payment data for email
                    $paymentData = array(
                        'invoiceNumber' => $invoiceId,
                        'customerName' => $customerData['FirstName'] . ' ' . $customerData['LastName'],
                        'customerEmail' => $customerData['Email'],
                        'amount' => $amountPaid,
                        'paymentMethod' => $paymentMethod,
                        'transactionID' => $transactionId
                    );
                    
                    // Send payment confirmation email asynchronously (non-blocking)
                    sendPaymentConfirmationEmailAsync($paymentData);
                    
                    // Set success message
                    $paymentMessage = '✅ Payment Successful! Your payment of Rs. ' . number_format($amountPaid, 2) . ' has been received. Transaction ID: ' . $transactionId . ' (Confirmation email sent)';
                    $paymentStatus = 'success';
                    $showPaymentAlert = true;
                    
                } else {
                    // Database update failed
                    $paymentMessage = '⚠️ Payment received but database update failed. Please contact support. Error: ' . mysqli_error($con);
                    $paymentStatus = 'warning';
                    $showPaymentAlert = true;
                }
                
            } else {
                // Payment already processed
                $paymentMessage = '✅ This invoice has already been paid.';
                $paymentStatus = 'info';
                $showPaymentAlert = true;
            }
            
        } else {
            // Payment not confirmed by Stripe
            $paymentMessage = '❌ Payment not confirmed. Status: ' . $session->payment_status;
            $paymentStatus = 'danger';
            $showPaymentAlert = true;
        }
        
    } catch (\Stripe\Exception\ApiErrorException $e) {
        // Stripe API error
        $paymentMessage = '❌ Error verifying payment: ' . $e->getMessage();
        $paymentStatus = 'danger';
        $showPaymentAlert = true;
        
    } catch (Exception $e) {
        // General error
        $paymentMessage = '❌ System error: ' . $e->getMessage();
        $paymentStatus = 'danger';
        $showPaymentAlert = true;
    }
}

// ==========================================
// STEP 3: Check if payment was cancelled
// ==========================================
if (isset($_GET['payment']) && $_GET['payment'] === 'cancelled') {
    $paymentMessage = 'ℹ️ Payment was cancelled. You can try again when ready.';
    $paymentStatus = 'warning';
    $showPaymentAlert = true;
}

?>
<!doctype html>
<html lang="en">
<head>
    <title>Salon Booking System | Invoice Details</title>

    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:400,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
    
    <!-- Custom CSS for payment alerts -->
    <style>
        .payment-alert {
            padding: 15px 20px;
            margin: 20px 0;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .payment-alert.success {
            background-color: #d4edda;
            color: #155724;
            border: 2px solid #c3e6cb;
        }
        .payment-alert.danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 2px solid #f5c6cb;
        }
        .payment-alert.warning {
            background-color: #fff3cd;
            color: #856404;
            border: 2px solid #ffeeba;
        }
        .payment-alert.info {
            background-color: #d1ecf1;
            color: #0c5460;
            border: 2px solid #bee5eb;
        }
        .btn-pay-now {
            background-color: #28a745;
            color: white;
            padding: 12px 30px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .btn-pay-now:hover {
            background-color: #218838;
        }
        .btn-paid {
            background-color: #6c757d;
            color: white;
            padding: 12px 30px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: not-allowed;
        }
        .payment-status-badge {
            display: inline-block;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 14px;
            margin-left: 10px;
        }
        .payment-status-badge.paid {
            background-color: #28a745;
            color: white;
        }
        .payment-status-badge.pending {
            background-color: #ffc107;
            color: #000;
        }
    </style>
</head>
<body id="home">
<?php include_once('includes/header.php');?> 

<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
<script>
    $(function () {
        $('.navbar-toggler').click(function () {
            $('body').toggleClass('noscroll');
        });
    });
</script>

<!-- Breadcrumbs -->
<section class="w3l-inner-banner-main">
    <div class="about-inner contact">
        <div class="container">
            <div class="main-titles-head text-center">
                <h3 class="header-name">Invoice Details</h3>
                <p class="tiltle-para">View your invoice and make payment securely.</p>
            </div>
        </div>
    </div>
    <div class="breadcrumbs-sub">
        <div class="container">
            <ul class="breadcrumbs-custom-path">
                <li class="right-side propClone">
                    <a href="index.php">Home <span class="fa fa-angle-right" aria-hidden="true"></span></a>
                </li>
                <li><a href="invoice-history.php">Invoice History <span class="fa fa-angle-right" aria-hidden="true"></span></a></li>
                <li class="active">Invoice Details</li>
            </ul>
        </div>
    </div>
</section>

<section class="w3l-contact-info-main" id="contact">
    <div class="contact-sec">
        <div class="container">
            
            <?php 
            // ==========================================
            // STEP 4: Display payment status message if exists
            // ==========================================
            if ($showPaymentAlert) { ?>
                <div class="payment-alert <?php echo $paymentStatus; ?>">
                    <?php echo $paymentMessage; ?>
                </div>
            <?php } ?>
            
            <div>
                <div class="cont-details">
                    <div class="table-content table-responsive cart-table-content m-t-30">
                        
                        <?php
                        // ==========================================
                        // STEP 5: Fetch and display invoice details
                        // ==========================================
                        
                        // Get invoice ID from URL
                        $invid = intval($_GET['invoiceid']);
                        
                        // Fetch customer details for this invoice
                        $ret = mysqli_query($con, "SELECT DISTINCT 
                                                    date(tblinvoice.PostingDate) as invoicedate, 
                                                    tbluser.FirstName, 
                                                    tbluser.LastName, 
                                                    tbluser.Email, 
                                                    tbluser.MobileNumber, 
                                                    tbluser.RegDate 
                                                  FROM tblinvoice 
                                                  JOIN tbluser ON tbluser.ID = tblinvoice.Userid 
                                                  WHERE tblinvoice.BillingId = '$invid'");

                        // Check if invoice exists
                        if (mysqli_num_rows($ret) > 0) {
                            $row = mysqli_fetch_array($ret);
                        ?>
                        
                        <div class="table-responsive bs-example widget-shadow">
                            <h4>Invoice #<?php echo $invid; ?></h4>
                            
                            <!-- Customer Information Table -->
                            <table class="table table-bordered" width="100%" border="1">
                                <tr>
                                    <th colspan="6" style="background-color: #f8f9fa;">Customer Details</th>
                                </tr>
                                <tr>
                                    <th>Name</th>
                                    <td><?php echo $row['FirstName'] . ' ' . $row['LastName']; ?></td>
                                    <th>Contact no.</th>
                                    <td><?php echo $row['MobileNumber']; ?></td>
                                    <th>Email</th>
                                    <td><?php echo $row['Email']; ?></td>
                                </tr>
                                <tr>
                                    <th>Registration Date</th>
                                    <td><?php echo $row['RegDate']; ?></td>
                                    <th>Invoice Date</th>
                                    <td colspan="3"><?php echo $row['invoicedate']; ?></td>
                                </tr>
                            </table>

                            <!-- Services and Payment Table -->
                            <table class="table table-bordered" width="100%" border="1">
                                <tr>
                                    <th colspan="4" style="background-color: #f8f9fa;">Services Details</th>
                                </tr>
                                <tr>
                                    <th>#</th>
                                    <th>Service</th>
                                    <th>Cost (Rs.)</th>
                                    <th>Payment Status</th>
                                </tr>

                                <?php
                                // Fetch all services for this invoice
                                $servicesQuery = mysqli_query($con, "SELECT 
                                                                        tblservices.ServiceName, 
                                                                        tblservices.Cost, 
                                                                        tblinvoice.PaymentStatus  
                                                                      FROM tblinvoice 
                                                                      JOIN tblservices ON tblservices.ID = tblinvoice.ServiceId 
                                                                      WHERE tblinvoice.BillingId = '$invid'");
                                
                                $cnt = 1; // Counter for serial number
                                $grandTotal = 0; // Initialize grand total
                                $currentPaymentStatus = 'Pending'; // Default status
                                
                                // Loop through each service
                                while ($service = mysqli_fetch_array($servicesQuery)) {
                                    $currentPaymentStatus = $service['PaymentStatus']; // Get payment status
                                    $serviceCost = $service['Cost'];
                                    $grandTotal += $serviceCost; // Add to grand total
                                ?>
                                <tr>
                                    <td><?php echo $cnt; ?></td>
                                    <td><?php echo $service['ServiceName']; ?></td>
                                    <td><?php echo number_format($serviceCost, 2); ?></td>
                                    <?php if ($cnt === 1) { // Show payment status only on first row ?>
                                        <td rowspan="<?php echo mysqli_num_rows($servicesQuery); ?>" style="text-align: center; vertical-align: middle;">
                                            <?php if (strtolower($currentPaymentStatus) === 'paid') { ?>
                                                <span class="payment-status-badge paid">✓ PAID</span>
                                            <?php } else { ?>
                                                <span class="payment-status-badge pending">⏳ PENDING</span>
                                            <?php } ?>
                                        </td>
                                    <?php } ?>
                                </tr>
                                <?php 
                                    $cnt++;
                                } 
                                ?>

                                <!-- Grand Total Row -->
                                <tr style="background-color: #f1f3f5;">
                                    <th colspan="2" style="text-align:right; font-size: 18px;">Grand Total:</th>
                                    <th style="font-size: 18px;">Rs. <?php echo number_format($grandTotal, 2); ?></th>
                                    <td></td>
                                </tr>

                                <!-- Payment Button Row -->
                                <tr>
                                    <td colspan="4" style="text-align:center; padding: 20px;">
                                        <?php 
                                        // ==========================================
                                        // STEP 6: Show appropriate button based on payment status
                                        // ==========================================
                                        if (strtolower($currentPaymentStatus) === 'paid') { 
                                        ?>
                                            <!-- Already Paid - Show disabled button -->
                                            <button class="btn-paid" disabled>
                                                ✓ Payment Completed
                                            </button>
                                            <p style="margin-top: 10px; color: #28a745; font-weight: bold;">
                                                This invoice has been paid. Thank you!
                                            </p>
                                        <?php } else { ?>
                                            <!-- Not Paid - Show Pay Now button -->
                                            <form action="stripe_payment.php" method="POST">
                                                <!-- Hidden fields to send amount and invoice ID -->
                                                <input type="hidden" name="amount" value="<?php echo $grandTotal; ?>">
                                                <input type="hidden" name="invoiceid" value="<?php echo $invid; ?>">
                                                
                                                <button type="submit" class="btn-pay-now">
                                                    💳 Pay Now - Rs. <?php echo number_format($grandTotal, 2); ?>
                                                </button>
                                            </form>
                                            <p style="margin-top: 10px; color: #666; font-size: 14px;">
                                                Secure payment powered by Stripe
                                            </p>
                                        <?php } ?>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- Print Button -->
                            <p style="margin-top:1%" align="center">
                                <i class="fa fa-print fa-2x" style="cursor: pointer;" onclick="window.print()" title="Print Invoice"></i>
                            </p>
                        </div>
                        
                        <?php 
                        } else {
                            // Invoice not found
                            echo '<div class="payment-alert danger">Invoice not found. Please check the invoice number.</div>';
                        }
                        ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include_once('includes/footer.php'); ?>

<!-- Move top button -->
<button onclick="topFunction()" id="movetop" title="Go to top">
    <span class="fa fa-long-arrow-up"></span>
</button>
<script>
    // Show/hide scroll to top button
    window.onscroll = function () {
        scrollFunction();
    };

    function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            document.getElementById("movetop").style.display = "block";
        } else {
            document.getElementById("movetop").style.display = "none";
        }
    }

    // Scroll to top function
    function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
</script>

</body>
</html>
