-- ================================================================================
-- CREATE TEST INVOICE FOR PAYMENT TESTING
-- Run this SQL in phpMyAdmin to quickly create a test invoice
-- ================================================================================

-- STEP 1: Check which customers exist
-- ================================================================================
SELECT ID, FirstName, LastName, Email, MobileNumber 
FROM tbluser 
ORDER BY ID DESC 
LIMIT 5;

-- Copy a User ID from above (e.g., 6)


-- STEP 2: Check which services exist
-- ================================================================================
SELECT ID, ServiceName, Cost 
FROM tblservices 
ORDER BY ID DESC 
LIMIT 10;

-- Copy a Service ID from above (e.g., 20)


-- STEP 3: Create a test invoice
-- ================================================================================
-- IMPORTANT: Replace the values below:
-- - Userid: Replace 6 with actual customer User ID
-- - ServiceId: Replace 20 with actual Service ID
-- - BillingId: Keep random number or change it

INSERT INTO tblinvoice (Userid, ServiceId, BillingId, PaymentStatus) 
VALUES 
(6, 20, 888777666, 'Pending');

-- After running above, the invoice will appear in customer's Invoice History!


-- STEP 4: Verify invoice was created
-- ================================================================================
SELECT 
    i.BillingId as 'Invoice Number',
    u.FirstName,
    u.LastName,
    s.ServiceName,
    s.Cost,
    i.PaymentStatus,
    i.PostingDate
FROM tblinvoice i
JOIN tbluser u ON u.ID = i.Userid
JOIN tblservices s ON s.ID = i.ServiceId
ORDER BY i.ID DESC
LIMIT 5;


-- OPTIONAL: Create invoice with multiple services
-- ================================================================================
-- This creates one invoice (same BillingId) with multiple services

INSERT INTO tblinvoice (Userid, ServiceId, BillingId, PaymentStatus) 
VALUES 
(6, 20, 777666555, 'Pending'),  -- Haircut
(6, 23, 777666555, 'Pending'),  -- Hair Color (same BillingId)
(6, 25, 777666555, 'Pending');  -- Facial (same BillingId)


-- CLEANUP: Delete test invoices after testing
-- ================================================================================
-- Replace 888777666 with your test invoice BillingId

-- DELETE FROM tblinvoice WHERE BillingId = 888777666;


-- ================================================================================
-- COMMON SCENARIOS
-- ================================================================================

-- Scenario 1: Create invoice for the most recent customer
-- --------------------------------------------------------------------------------
INSERT INTO tblinvoice (Userid, ServiceId, BillingId, PaymentStatus)
SELECT 
    (SELECT ID FROM tbluser ORDER BY ID DESC LIMIT 1) as Userid,
    20 as ServiceId,
    FLOOR(RAND() * 900000000) + 100000000 as BillingId,
    'Pending' as PaymentStatus;


-- Scenario 2: Check if invoice already exists for a customer
-- --------------------------------------------------------------------------------
SELECT 
    BillingId,
    COUNT(*) as ServiceCount,
    SUM(s.Cost) as TotalAmount,
    PaymentStatus
FROM tblinvoice i
JOIN tblservices s ON s.ID = i.ServiceId
WHERE Userid = 6  -- Replace with customer ID
GROUP BY BillingId, PaymentStatus
ORDER BY BillingId DESC;


-- Scenario 3: Mark invoice as paid (for testing)
-- --------------------------------------------------------------------------------
-- Replace 888777666 with actual BillingId

-- UPDATE tblinvoice 
-- SET PaymentStatus = 'paid' 
-- WHERE BillingId = 888777666;


-- Scenario 4: Reset invoice to pending (for re-testing payment)
-- --------------------------------------------------------------------------------
-- Replace 888777666 with actual BillingId

-- UPDATE tblinvoice 
-- SET PaymentStatus = 'Pending' 
-- WHERE BillingId = 888777666;


-- ================================================================================
-- TROUBLESHOOTING
-- ================================================================================

-- Check if PaymentStatus column exists
-- --------------------------------------------------------------------------------
SHOW COLUMNS FROM tblinvoice LIKE 'PaymentStatus';

-- If above returns empty, add the column:
-- ALTER TABLE tblinvoice ADD COLUMN PaymentStatus VARCHAR(10) DEFAULT 'Pending';


-- Check if tblpayments table exists
-- --------------------------------------------------------------------------------
SHOW TABLES LIKE 'tblpayments';

-- If table doesn't exist, create it (optional):
-- CREATE TABLE tblpayments (
--     PaymentID INT PRIMARY KEY AUTO_INCREMENT,
--     AppointmentNumber INT,
--     PaymentStatus VARCHAR(10) DEFAULT 'Pending',
--     PaymentDate DATETIME DEFAULT CURRENT_TIMESTAMP,
--     Amount DECIMAL(10,2),
--     PaymentMethod VARCHAR(50),
--     TransactionID VARCHAR(100)
-- );


-- ================================================================================
-- QUICK REFERENCE
-- ================================================================================

-- Table Structure:
-- tbluser: Stores customer information (ID, FirstName, LastName, Email, etc.)
-- tblservices: Stores service information (ID, ServiceName, Cost, etc.)
-- tblinvoice: Stores invoices (Userid, ServiceId, BillingId, PaymentStatus)

-- Important Fields:
-- Userid: Links to tbluser.ID (which customer)
-- ServiceId: Links to tblservices.ID (which service)
-- BillingId: Unique invoice number (9-digit random number)
-- PaymentStatus: 'Pending' or 'paid'

-- ================================================================================
-- NOTES
-- ================================================================================

-- 1. BillingId must be unique for each invoice
-- 2. Same BillingId with different ServiceId = Multiple services in one invoice
-- 3. PaymentStatus values: 'Pending', 'paid' (case sensitive!)
-- 4. After creating invoice, customer can see it in Invoice History
-- 5. Customer can only pay if PaymentStatus is 'Pending'
-- 6. After payment, PaymentStatus changes to 'paid'

-- ================================================================================

