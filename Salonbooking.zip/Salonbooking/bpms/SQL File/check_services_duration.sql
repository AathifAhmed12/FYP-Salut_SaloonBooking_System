-- Check if Duration column exists and view all services with their durations
SELECT 
    ID,
    ServiceName,
    Cost,
    Duration
FROM tblservices
ORDER BY ServiceName;

