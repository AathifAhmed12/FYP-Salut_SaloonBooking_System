-- ============================================
-- PERFORMANCE OPTIMIZATION: DATABASE INDEXES (SAFE VERSION)
-- ============================================
-- This version uses a stored procedure to safely add indexes
-- It checks if indexes exist before creating them
-- No duplicate key errors will occur
-- ============================================

-- Create stored procedure to safely add indexes
DELIMITER $$

DROP PROCEDURE IF EXISTS AddIndexIfNotExists$$
CREATE PROCEDURE AddIndexIfNotExists(
    IN p_table_name VARCHAR(64),
    IN p_index_name VARCHAR(64),
    IN p_index_columns VARCHAR(255)
)
BEGIN
    DECLARE v_index_exists INT DEFAULT 0;
    
    SELECT COUNT(*) INTO v_index_exists
    FROM INFORMATION_SCHEMA.STATISTICS
    WHERE table_schema = DATABASE()
      AND table_name = p_table_name
      AND index_name = p_index_name;
    
    IF v_index_exists = 0 THEN
        SET @sql = CONCAT('ALTER TABLE `', p_table_name, '` ADD INDEX `', p_index_name, '` (', p_index_columns, ')');
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        SELECT CONCAT('Index ', p_index_name, ' created on ', p_table_name) AS result;
    ELSE
        SELECT CONCAT('Index ', p_index_name, ' already exists on ', p_table_name) AS result;
    END IF;
END$$

DELIMITER ;

-- ============================================
-- Now add all indexes using the safe procedure
-- ============================================

-- Indexes for tblservices
CALL AddIndexIfNotExists('tblservices', 'idx_id', 'ID');
CALL AddIndexIfNotExists('tblservices', 'idx_servicename', 'ServiceName');

-- Indexes for tblbook
CALL AddIndexIfNotExists('tblbook', 'idx_userid', 'UserID');
CALL AddIndexIfNotExists('tblbook', 'idx_status', 'Status');
CALL AddIndexIfNotExists('tblbook', 'idx_aptdate', 'AptDate');
CALL AddIndexIfNotExists('tblbook', 'idx_id', 'ID');
CALL AddIndexIfNotExists('tblbook', 'idx_stylistid', 'StylistID');

-- Indexes for tbluser
CALL AddIndexIfNotExists('tbluser', 'idx_id', 'ID');
CALL AddIndexIfNotExists('tbluser', 'idx_email', 'Email');

-- Indexes for tblstylist
CALL AddIndexIfNotExists('tblstylist', 'idx_id', 'ID');
CALL AddIndexIfNotExists('tblstylist', 'idx_stylistname', 'StylistName');

-- Indexes for tblinvoice
CALL AddIndexIfNotExists('tblinvoice', 'idx_userid', 'Userid');
CALL AddIndexIfNotExists('tblinvoice', 'idx_serviceid', 'ServiceId');
CALL AddIndexIfNotExists('tblinvoice', 'idx_billingid', 'BillingId');
CALL AddIndexIfNotExists('tblinvoice', 'idx_paymentstatus', 'PaymentStatus');

-- Indexes for tblstylist_reviews (only if table exists)
CALL AddIndexIfNotExists('tblstylist_reviews', 'idx_stylistid', 'StylistID');
CALL AddIndexIfNotExists('tblstylist_reviews', 'idx_userid', 'UserID');
CALL AddIndexIfNotExists('tblstylist_reviews', 'idx_status', 'Status');

-- Composite indexes
CALL AddIndexIfNotExists('tblbook', 'idx_user_status', 'UserID, Status');
CALL AddIndexIfNotExists('tblinvoice', 'idx_billing_payment', 'BillingId, PaymentStatus');

-- Clean up: Drop the stored procedure after use
DROP PROCEDURE IF EXISTS AddIndexIfNotExists;

-- ============================================
-- DONE! All indexes have been safely added
-- ============================================

