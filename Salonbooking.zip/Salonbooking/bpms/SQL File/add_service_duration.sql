-- Add Duration column to tblservices table
-- This stores the service duration in minutes

ALTER TABLE tblservices ADD COLUMN Duration INT(11) DEFAULT 60 AFTER Cost;

-- Update existing services with their durations (in minutes)
UPDATE tblservices SET Duration = 30 WHERE ServiceName = 'Haircut';
UPDATE tblservices SET Duration = 20 WHERE ServiceName = 'Beard Trim';
UPDATE tblservices SET Duration = 20 WHERE ServiceName = 'shave';
UPDATE tblservices SET Duration = 90 WHERE ServiceName = 'Hair Coloring';
UPDATE tblservices SET Duration = 60 WHERE ServiceName = 'hair styling';
UPDATE tblservices SET Duration = 60 WHERE ServiceName = 'Pedicure';
UPDATE tblservices SET Duration = 45 WHERE ServiceName = 'Manicure';
UPDATE tblservices SET Duration = 60 WHERE ServiceName = 'Facial treatment';
UPDATE tblservices SET Duration = 120 WHERE ServiceName = 'makeup';

-- If you have different service names, run these individually:
-- UPDATE tblservices SET Duration = [minutes] WHERE ServiceName = 'YourServiceName';

