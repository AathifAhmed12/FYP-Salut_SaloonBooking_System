-- Safe SQL Script to Update Service Durations
-- This script will work whether the Duration column exists or not

-- Update existing services with specified durations (in minutes)
-- If Duration column doesn't exist, these will simply fail silently

UPDATE tblservices SET Duration = 30 WHERE ServiceName LIKE '%Haircut%';
UPDATE tblservices SET Duration = 20 WHERE ServiceName LIKE '%Beard%';
UPDATE tblservices SET Duration = 20 WHERE ServiceName LIKE '%shave%';
UPDATE tblservices SET Duration = 90 WHERE ServiceName LIKE '%Color%';
UPDATE tblservices SET Duration = 60 WHERE ServiceName LIKE '%styling%';
UPDATE tblservices SET Duration = 60 WHERE ServiceName LIKE '%Pedicure%';
UPDATE tblservices SET Duration = 45 WHERE ServiceName LIKE '%Manicure%';
UPDATE tblservices SET Duration = 60 WHERE ServiceName LIKE '%Facial%';
UPDATE tblservices SET Duration = 120 WHERE ServiceName LIKE '%makeup%';

-- Set default 60 minutes for any services that don't have a duration set
UPDATE tblservices SET Duration = 60 WHERE Duration IS NULL OR Duration = 0;

