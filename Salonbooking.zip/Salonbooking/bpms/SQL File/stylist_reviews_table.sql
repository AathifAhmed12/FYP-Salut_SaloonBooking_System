-- ====================================
-- STYLIST REVIEWS & RATINGS TABLE
-- ====================================

CREATE TABLE IF NOT EXISTS `tblstylist_reviews` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `StylistID` int(10) NOT NULL,
  `UserID` int(10) NOT NULL,
  `Rating` int(1) NOT NULL COMMENT '1 to 5 stars',
  `Review` text DEFAULT NULL,
  `ReviewDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `Status` varchar(20) DEFAULT 'Approved' COMMENT 'Approved, Pending, Rejected',
  PRIMARY KEY (`ID`),
  KEY `StylistID` (`StylistID`),
  KEY `UserID` (`UserID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Sample data (optional)
-- INSERT INTO `tblstylist_reviews` (`StylistID`, `UserID`, `Rating`, `Review`, `Status`) 
-- VALUES (1, 1, 5, 'Excellent service! Very professional.', 'Approved');

