<?php
/**
 * Payment Integration Test Page
 * Use this page to verify your Stripe payment setup is working correctly
 */

session_start();
include('includes/dbconnection.php');
require '../vendor/autoload.php';

// Set Stripe API Key
\Stripe\Stripe::setApiKey('sk_test_51QCdFlLrGzRaEuveCrzRu8TyHnCYfix77jbknTmfpXgeZHZwAGnrZ3AbFG0mReigcc05y766BKh6u5cce8bxdIBj00V1TEojwL');

// Test results array
$tests = [];

// ============================================
// TEST 1: Stripe Library Check
// ============================================
try {
    $stripeVersion = \Stripe\Stripe::VERSION;
    $tests[] = [
        'name' => 'Stripe PHP Library',
        'status' => 'pass',
        'message' => "✅ Stripe library loaded successfully (Version: $stripeVersion)"
    ];
} catch (Exception $e) {
    $tests[] = [
        'name' => 'Stripe PHP Library',
        'status' => 'fail',
        'message' => "❌ Failed to load Stripe library: " . $e->getMessage()
    ];
}

// ============================================
// TEST 2: Stripe API Connection
// ============================================
try {
    $balance = \Stripe\Balance::retrieve();
    $tests[] = [
        'name' => 'Stripe API Connection',
        'status' => 'pass',
        'message' => "✅ Successfully connected to Stripe API"
    ];
} catch (\Stripe\Exception\AuthenticationException $e) {
    $tests[] = [
        'name' => 'Stripe API Connection',
        'status' => 'fail',
        'message' => "❌ Invalid API key. Please check your Stripe secret key."
    ];
} catch (Exception $e) {
    $tests[] = [
        'name' => 'Stripe API Connection',
        'status' => 'fail',
        'message' => "❌ Connection failed: " . $e->getMessage()
    ];
}

// ============================================
// TEST 3: Database Connection
// ============================================
if ($con) {
    $tests[] = [
        'name' => 'Database Connection',
        'status' => 'pass',
        'message' => "✅ Database connected successfully"
    ];
} else {
    $tests[] = [
        'name' => 'Database Connection',
        'status' => 'fail',
        'message' => "❌ Database connection failed: " . mysqli_connect_error()
    ];
}

// ============================================
// TEST 4: Check tblinvoice table
// ============================================
$tableCheck = mysqli_query($con, "SHOW TABLES LIKE 'tblinvoice'");
if (mysqli_num_rows($tableCheck) > 0) {
    $tests[] = [
        'name' => 'tblinvoice Table',
        'status' => 'pass',
        'message' => "✅ tblinvoice table exists"
    ];
    
    // Check for PaymentStatus column
    $columnCheck = mysqli_query($con, "SHOW COLUMNS FROM tblinvoice LIKE 'PaymentStatus'");
    if (mysqli_num_rows($columnCheck) > 0) {
        $tests[] = [
            'name' => 'PaymentStatus Column',
            'status' => 'pass',
            'message' => "✅ PaymentStatus column exists in tblinvoice"
        ];
    } else {
        $tests[] = [
            'name' => 'PaymentStatus Column',
            'status' => 'warning',
            'message' => "⚠️ PaymentStatus column missing in tblinvoice. Payment status updates may fail."
        ];
    }
} else {
    $tests[] = [
        'name' => 'tblinvoice Table',
        'status' => 'fail',
        'message' => "❌ tblinvoice table does not exist"
    ];
}

// ============================================
// TEST 5: Check tblpayments table
// ============================================
$paymentTableCheck = mysqli_query($con, "SHOW TABLES LIKE 'tblpayments'");
if (mysqli_num_rows($paymentTableCheck) > 0) {
    $tests[] = [
        'name' => 'tblpayments Table',
        'status' => 'pass',
        'message' => "✅ tblpayments table exists"
    ];
} else {
    $tests[] = [
        'name' => 'tblpayments Table',
        'status' => 'warning',
        'message' => "⚠️ tblpayments table does not exist. Consider creating it for better payment tracking."
    ];
}

// ============================================
// TEST 6: Check for pending invoices
// ============================================
$invoiceCheck = mysqli_query($con, "SELECT COUNT(*) as count FROM tblinvoice");
$invoiceData = mysqli_fetch_array($invoiceCheck);
if ($invoiceData['count'] > 0) {
    $tests[] = [
        'name' => 'Invoice Data',
        'status' => 'pass',
        'message' => "✅ Found {$invoiceData['count']} invoice(s) in database"
    ];
    
    // Check for pending invoices
    $pendingCheck = mysqli_query($con, "SELECT COUNT(*) as count FROM tblinvoice WHERE PaymentStatus IS NULL OR PaymentStatus = 'Pending'");
    $pendingData = mysqli_fetch_array($pendingCheck);
    if ($pendingData['count'] > 0) {
        $tests[] = [
            'name' => 'Pending Payments',
            'status' => 'info',
            'message' => "ℹ️ Found {$pendingData['count']} pending payment(s)"
        ];
    }
} else {
    $tests[] = [
        'name' => 'Invoice Data',
        'status' => 'warning',
        'message' => "⚠️ No invoices found. Create an invoice to test payments."
    ];
}

// ============================================
// TEST 7: File existence check
// ============================================
$requiredFiles = [
    'stripe_payment.php' => 'Stripe payment handler',
    'view-invoice.php' => 'Invoice view page',
    'invoice-history.php' => 'Invoice history page',
    '../vendor/autoload.php' => 'Composer autoloader'
];

foreach ($requiredFiles as $file => $description) {
    if (file_exists($file)) {
        $tests[] = [
            'name' => $description,
            'status' => 'pass',
            'message' => "✅ $file exists"
        ];
    } else {
        $tests[] = [
            'name' => $description,
            'status' => 'fail',
            'message' => "❌ $file not found"
        ];
    }
}

// Calculate overall status
$totalTests = count($tests);
$passedTests = count(array_filter($tests, function($test) { return $test['status'] === 'pass'; }));
$failedTests = count(array_filter($tests, function($test) { return $test['status'] === 'fail'; }));
$warningTests = count(array_filter($tests, function($test) { return $test['status'] === 'warning'; }));

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Integration Test</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }
        
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .header p {
            opacity: 0.9;
            font-size: 14px;
        }
        
        .summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            padding: 30px;
            background: #f8f9fa;
            border-bottom: 2px solid #e9ecef;
        }
        
        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .summary-card h3 {
            font-size: 32px;
            margin-bottom: 5px;
        }
        
        .summary-card p {
            color: #6c757d;
            font-size: 14px;
        }
        
        .summary-card.pass h3 { color: #28a745; }
        .summary-card.fail h3 { color: #dc3545; }
        .summary-card.warning h3 { color: #ffc107; }
        
        .tests {
            padding: 30px;
        }
        
        .test-item {
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            transition: all 0.3s;
        }
        
        .test-item:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        
        .test-item.pass {
            border-left: 5px solid #28a745;
        }
        
        .test-item.fail {
            border-left: 5px solid #dc3545;
        }
        
        .test-item.warning {
            border-left: 5px solid #ffc107;
        }
        
        .test-item.info {
            border-left: 5px solid #17a2b8;
        }
        
        .test-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .test-name {
            font-weight: bold;
            font-size: 16px;
            color: #333;
        }
        
        .test-status {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .test-status.pass {
            background: #d4edda;
            color: #155724;
        }
        
        .test-status.fail {
            background: #f8d7da;
            color: #721c24;
        }
        
        .test-status.warning {
            background: #fff3cd;
            color: #856404;
        }
        
        .test-status.info {
            background: #d1ecf1;
            color: #0c5460;
        }
        
        .test-message {
            color: #6c757d;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .footer {
            background: #f8f9fa;
            padding: 20px 30px;
            text-align: center;
            border-top: 2px solid #e9ecef;
        }
        
        .footer a {
            display: inline-block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            text-decoration: none;
            margin: 5px;
            transition: transform 0.3s;
        }
        
        .footer a:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .overall-status {
            text-align: center;
            padding: 30px;
            font-size: 24px;
            font-weight: bold;
        }
        
        .overall-status.pass {
            color: #28a745;
        }
        
        .overall-status.fail {
            color: #dc3545;
        }
        
        .test-cards {
            padding: 20px 30px;
            background: #fff9e6;
            border-top: 2px solid #ffd700;
        }
        
        .test-cards h3 {
            margin-bottom: 15px;
            color: #333;
        }
        
        .card-item {
            background: white;
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }
        
        .card-item strong {
            color: #667eea;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔍 Payment Integration Test Results</h1>
            <p>Verify your Stripe payment setup is configured correctly</p>
        </div>
        
        <div class="summary">
            <div class="summary-card pass">
                <h3><?php echo $passedTests; ?></h3>
                <p>Passed</p>
            </div>
            <div class="summary-card fail">
                <h3><?php echo $failedTests; ?></h3>
                <p>Failed</p>
            </div>
            <div class="summary-card warning">
                <h3><?php echo $warningTests; ?></h3>
                <p>Warnings</p>
            </div>
            <div class="summary-card">
                <h3><?php echo $totalTests; ?></h3>
                <p>Total Tests</p>
            </div>
        </div>
        
        <div class="overall-status <?php echo $failedTests > 0 ? 'fail' : 'pass'; ?>">
            <?php if ($failedTests > 0): ?>
                ⚠️ Some tests failed. Please fix the issues above.
            <?php elseif ($warningTests > 0): ?>
                ✓ All critical tests passed! Some warnings need attention.
            <?php else: ?>
                ✅ All tests passed! Payment system is ready to use.
            <?php endif; ?>
        </div>
        
        <div class="tests">
            <h2 style="margin-bottom: 20px; color: #333;">Test Results</h2>
            <?php foreach ($tests as $test): ?>
                <div class="test-item <?php echo $test['status']; ?>">
                    <div class="test-header">
                        <div class="test-name"><?php echo $test['name']; ?></div>
                        <div class="test-status <?php echo $test['status']; ?>">
                            <?php echo $test['status']; ?>
                        </div>
                    </div>
                    <div class="test-message"><?php echo $test['message']; ?></div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="test-cards">
            <h3>🧪 Stripe Test Card Numbers</h3>
            <div class="card-item">
                <strong>Success:</strong> 4242 4242 4242 4242
            </div>
            <div class="card-item">
                <strong>Declined:</strong> 4000 0000 0000 0002
            </div>
            <div class="card-item">
                <strong>Requires Authentication:</strong> 4000 0027 6000 3184
            </div>
            <p style="margin-top: 15px; font-size: 13px; color: #6c757d;">
                Use any future expiry date, any 3-digit CVC, and any ZIP code
            </p>
        </div>
        
        <div class="footer">
            <a href="invoice-history.php">📄 View Invoices</a>
            <a href="STRIPE_PAYMENT_GUIDE.md" target="_blank">📚 Read Guide</a>
            <a href="javascript:location.reload()">🔄 Refresh Tests</a>
        </div>
    </div>
</body>
</html>

