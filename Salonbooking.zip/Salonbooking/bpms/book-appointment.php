<?php 
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bpmsuid']==0)) {
  header('location:logout.php');
  } else{

    if (isset($_POST['submit'])) {
        $uid = $_SESSION['bpmsuid'];
        $adate = $_POST['adate'];
        $atime = $_POST['atime'];
        $stylistID = $_POST['stylist'];  // Get the selected stylist ID
        $msg = $_POST['message'];
        $aptnumber = mt_rand(100000000, 999999999);
    
        // Check if services are selected
        if (empty($_POST['services'])) {
            echo '<script>alert("Please select at least one service")</script>';
        } else {
            $selectedServices = $_POST['services'];  // Array of selected service IDs
            
            // ============================================
            // OPTIMIZED: Fetch all service names in ONE query (fixes N+1 problem)
            // ============================================
            $serviceIDs = array_map('intval', $selectedServices); // Sanitize IDs
            $serviceIDsList = implode(',', $serviceIDs);
            
            // Single query to get all service names at once
            $serviceQuery = mysqli_query($con, "SELECT ID, ServiceName FROM tblservices WHERE ID IN ($serviceIDsList)");
            $serviceNames = array();
            while ($serviceResult = mysqli_fetch_array($serviceQuery)) {
                $serviceNames[] = $serviceResult['ServiceName'];
            }
            
            // Join service names with comma
            $serviceName = implode(', ', $serviceNames);
            
            // Fetch the stylist name based on the stylist ID (with prepared statement)
            $stylistID = intval($stylistID); // Sanitize
            $stylistQuery = mysqli_query($con, "SELECT StylistName FROM tblstylist WHERE ID = '$stylistID'");
            $stylistResult = mysqli_fetch_array($stylistQuery);
            $stylistName = $stylistResult ? $stylistResult['StylistName'] : 'Not Assigned';
        
            // Insert into tblbook using prepared statement approach
            $uid = intval($uid);
            $aptnumber = intval($aptnumber);
            $serviceNameEscaped = mysqli_real_escape_string($con, $serviceName);
            $stylistNameEscaped = mysqli_real_escape_string($con, $stylistName);
            $msgEscaped = mysqli_real_escape_string($con, $msg);
            $adateEscaped = mysqli_real_escape_string($con, $adate);
            $atimeEscaped = mysqli_real_escape_string($con, $atime);
            
            $query = mysqli_query($con, "INSERT INTO tblbook(UserID, AptNumber, AptDate, AptTime, ServiceName, StylistID, StylistName, Message) VALUES('$uid', '$aptnumber', '$adateEscaped', '$atimeEscaped', '$serviceNameEscaped', '$stylistID', '$stylistNameEscaped', '$msgEscaped')");
    
        if ($query) {
                // No need for separate query - we already have aptnumber
                $_SESSION['aptno'] = $aptnumber;
                
                // ============================================
                // OPTIMIZED: Get customer details and send emails async (non-blocking)
                // ============================================
                include('includes/email-config.php');
                
                // Get customer details for email (single query)
                $userQuery = mysqli_query($con, "SELECT FirstName, LastName, Email, MobileNumber FROM tbluser WHERE ID='$uid'");
                $userData = mysqli_fetch_array($userQuery);
                
                if ($userData) {
                    // Prepare booking data for email
                    $bookingData = array(
                        'appointmentNumber' => $aptnumber,
                        'customerName' => $userData['FirstName'] . ' ' . $userData['LastName'],
                        'customerEmail' => $userData['Email'],
                        'customerPhone' => $userData['MobileNumber'],
                        'appointmentDate' => $adate,
                        'appointmentTime' => $atime,
                        'services' => $serviceName,
                        'stylist' => $stylistName,
                        'message' => $msg
                    );
                    
                    // Send emails asynchronously (non-blocking) - page responds immediately!
                    sendBookingConfirmationEmailAsync($bookingData);
                    sendNewBookingNotificationToAdminAsync($bookingData);
                }
                
                // Redirect immediately - emails send in background
            echo "<script>window.location.href='thank-you.php'</script>";
        } else {
            echo '<script>alert("Something Went Wrong. Please try again")</script>';
            }
        }
    }
    
    
?>
<!doctype html>
<html lang="en">
  <head>
 

    <title>Salon Booking System  | Appointment Page</title>

    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Slab:400,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">
    <style>
        /* Professional Checkbox Styling for Services */
        .service-selection-container {
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            margin-top: 30px;
        }
        .service-checkbox-group {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        .service-checkbox-item {
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
        }
        .service-checkbox-item:hover {
            border-color: #007bff;
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.15);
            transform: translateY(-2px);
        }
        .service-checkbox-item input[type="checkbox"] {
            position: absolute;
            opacity: 0;
            cursor: pointer;
        }
        .service-checkbox-item input[type="checkbox"]:checked ~ .service-checkmark {
            background-color: #007bff;
            border-color: #007bff;
        }
        .service-checkbox-item input[type="checkbox"]:checked ~ .service-checkmark:after {
            display: block;
        }
        .service-checkbox-item input[type="checkbox"]:checked ~ .service-info {
            color: #007bff;
            font-weight: 600;
        }
        .service-checkbox-item.selected {
            border-color: #007bff;
            background-color: #f0f7ff;
        }
        .service-checkmark {
            position: absolute;
            top: 15px;
            right: 15px;
            height: 24px;
            width: 24px;
            background-color: white;
            border: 2px solid #ccc;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        .service-checkmark:after {
            content: "";
            position: absolute;
            display: none;
            left: 7px;
            top: 3px;
            width: 6px;
            height: 11px;
            border: solid white;
            border-width: 0 2px 2px 0;
            transform: rotate(45deg);
        }
        .service-info {
            padding-right: 40px;
            transition: all 0.3s ease;
        }
        .service-name {
            font-size: 16px;
            font-weight: 500;
            color: #333;
            margin-bottom: 5px;
        }
        .service-cost {
            font-size: 14px;
            color: #28a745;
            font-weight: 600;
        }
        .selected-services-summary {
            margin-top: 15px;
            padding: 12px;
            background: #e7f3ff;
            border-left: 4px solid #007bff;
            border-radius: 4px;
            display: none;
        }
        .selected-services-summary.show {
            display: block;
        }
        .selection-label {
            font-size: 15px;
            font-weight: 600;
            color: #333;
            margin-bottom: 10px;
            display: block;
        }
    </style>
  <!-- Load jQuery in HEAD before any other scripts -->
  <script src="assets/js/jquery-3.3.1.min.js"></script>
  </head>
  <body id="home">
<?php include_once('includes/header.php');?>

<!--bootstrap working-->
<script src="assets/js/bootstrap.min.js"></script>
<!-- //bootstrap working-->
<!-- disable body scroll which navbar is in active -->
<script>
$(function () {
  $('.navbar-toggler').click(function () {
    $('body').toggleClass('noscroll');
  })
});
</script>
<!-- disable body scroll which navbar is in active -->

<!-- breadcrumbs -->
<section class="w3l-inner-banner-main">
    <div class="about-inner contact" style="background: url('https://images.unsplash.com/photo-1560066984-138dadb4c035?w=1200&q=80') no-repeat center center; background-size: cover;">
        <div class="container">   
            <div class="main-titles-head text-center">
            <h3 class="header-name ">
                
 Book Appointment
            </h3>
            <p class="tiltle-para ">Select your preferred services, choose your favorite stylist, and book your appointment at a time that works for you.</p>
        </div>
</div>
</div>
<div class="breadcrumbs-sub">
<div class="container">   
<ul class="breadcrumbs-custom-path">
    <li class="right-side propClone"><a href="index.php" class="">Home <span class="fa fa-angle-right" aria-hidden="true"></span></a> <p></li>
    <li class="active ">
        Book Appointment</li>
</ul>
</div>
</div>
    </div>
</section>
<!-- breadcrumbs //-->
<section class="w3l-contact-info-main" id="contact">
    <div class="contact-sec	">
        <div class="container">

            <div class="d-grid contact-view">
                <div class="cont-details">
                    <?php

$ret=mysqli_query($con,"select * from tblpage where PageType='contactus' ");
$cnt=1;
while ($row=mysqli_fetch_array($ret)) {

?>
                    <div class="cont-top">
                        <div class="cont-left text-center">
                            <span class="fa fa-phone text-primary"></span>
                        </div>
                        <div class="cont-right">
                            <h6>Call Us</h6>
                            <p class="para"><a href="tel:+44 99 555 42">+<?php  echo $row['MobileNumber'];?></a></p>
                        </div>
                    </div>
                    <div class="cont-top margin-up">
                        <div class="cont-left text-center">
                            <span class="fa fa-envelope-o text-primary"></span>
                        </div>
                        <div class="cont-right">
                            <h6>Email Us</h6>
                            <p class="para"><a href="mailto:example@mail.com" class="mail"><?php  echo $row['Email'];?></a></p>
                        </div>
                    </div>
                    <div class="cont-top margin-up">
                        <div class="cont-left text-center">
                            <span class="fa fa-map-marker text-primary"></span>
                        </div>
                        <div class="cont-right">
                            <h6>Address</h6>
                            <p class="para"> <?php  echo $row['PageDescription'];?></p>
                        </div>
                    </div>
                    <div class="cont-top margin-up">
                        <div class="cont-left text-center">
                            <span class="fa fa-map-marker text-primary"></span>
                        </div>
                        <div class="cont-right">
                            <h6>Time</h6>
                            <p class="para"> <?php  echo $row['Timing'];?></p>
                        </div>
                    </div>
               <?php } ?> </div>
                <div class="map-content-9 mt-lg-0 mt-4">
                <form method="post">
    <!-- Step 1: Appointment Date -->
    <div style="padding-top: 30px;">
        <label>Appointment Date</label>
        <input type="date" class="form-control appointment_date" name="adate" id="adate" required="true">
</div>

    <!-- Step 2: Select Services -->
    <div class="service-selection-container">
        <label class="selection-label">Select Services (You can choose multiple)</label>
        <div class="service-checkbox-group">
            <?php
            $query = mysqli_query($con, "SELECT * FROM tblservices");
            while ($row = mysqli_fetch_array($query)) {
                // Set default duration if Duration column doesn't exist yet
                $duration = isset($row['Duration']) && $row['Duration'] > 0 ? $row['Duration'] : 60;
            ?>
                <label class="service-checkbox-item">
                    <input type="checkbox" name="services[]" value="<?php echo $row['ID']; ?>" data-duration="<?php echo $duration; ?>">
                    <span class="service-checkmark"></span>
                    <div class="service-info">
                        <div class="service-name"><?php echo $row['ServiceName']; ?></div>
                        <div class="service-cost">Rs. <?php echo number_format($row['Cost'], 2); ?> | <?php echo $duration; ?> min</div>
                    </div>
                </label>
            <?php } ?>
        </div>
        <div class="selected-services-summary" id="selectedServicesSummary">
            <strong>Selected Services:</strong> <span id="selectedServicesList"></span>
        </div>
    </div>

    <!-- Step 3: Select Stylist -->
    <div style="padding-top: 30px;">
        <label>Select Stylist</label>
        <select class="form-control" name="stylist" id="stylist" required="true">
            <option value="">Select Stylist</option>
            <?php
            $stylistQuery = mysqli_query($con, "SELECT * FROM tblstylist WHERE Status='Active'");
            while ($stylistRow = mysqli_fetch_array($stylistQuery)) {
                echo '<option value="'.$stylistRow['ID'].'">'.$stylistRow['StylistName'].' - '.$stylistRow['Specialization'].'</option>';
            }
            ?>
        </select>
    </div>

    <!-- Step 4: Appointment Time (Auto-loads after selecting date, services, and stylist) -->
    <div style="padding-top: 30px;">
        <label>Appointment Time</label>
        <select class="form-control" name="atime" id="atime" required="true" disabled>
            <option value="">Please select date, services, and stylist first</option>
        </select>
        <small class="form-text text-muted" id="timeSlotHelp" style="display:none;">Available time slots based on stylist's schedule and service duration</small>
    </div>

    <!-- Step 5: Message -->
    <div style="padding-top: 30px;">
        <label>Message (Optional)</label>
        <textarea class="form-control" id="message" name="message" placeholder="Any special requests or notes..." rows="4"></textarea>
    </div>

    <!-- Submit Button -->
    <div style="padding-top: 20px;">
    <button type="submit" class="btn btn-contact" name="submit">Make an Appointment</button>
    </div>
</form>

                </div>
    </div>
   
    </div></div>
</section>

<!-- Appointment History Section -->
<section class="w3l-contact-info-main" id="appointment-history" style="padding-top: 50px; background: #f8f9fa;">
    <div class="contact-sec">
        <div class="container">
            <div class="main-titles-head text-center" style="margin-bottom: 30px;">
                <h3 class="header-name">Your Appointment History</h3>
                <p class="tiltle-para">View all your previous and upcoming appointments</p>
            </div>
            
            <div>
                <div class="cont-details">
                   <div class="table-content table-responsive cart-table-content m-t-30">
                        <table border="2" class="table" style="background: white;">
                            <thead class="gray-bg">
                                <tr>
                                    <th>#</th>
                                    <th>Appointment Number</th>
                                    <th>Appointment Date</th>
                                    <th>Appointment Time</th>
                                    <th>Appointment Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // OPTIMIZED: Add pagination for appointment history
                                $userid = $_SESSION['bpmsuid'];
                                $page = isset($_GET['hist_page']) ? intval($_GET['hist_page']) : 1;
                                $perPage = 10; // Show 10 appointments per page
                                $offset = ($page - 1) * $perPage;
                                
                                // Get total count
                                $countQuery = mysqli_query($con, "SELECT COUNT(*) as total FROM tblbook WHERE UserID='$userid'");
                                $countRow = mysqli_fetch_array($countQuery);
                                $totalRecords = $countRow['total'];
                                $totalPages = ceil($totalRecords / $perPage);
                                
                                // OPTIMIZED: Fetch only required records with LIMIT
                                $query = mysqli_query($con, "SELECT tbluser.ID as uid, tbluser.FirstName, tbluser.LastName, tbluser.Email, tbluser.MobileNumber, tblbook.ID as bid, tblbook.AptNumber, tblbook.AptDate, tblbook.AptTime, tblbook.Message, tblbook.BookingDate, tblbook.Status 
                                FROM tblbook 
                                JOIN tbluser ON tbluser.ID=tblbook.UserID 
                                WHERE tbluser.ID='$userid' 
                                ORDER BY tblbook.ID DESC 
                                LIMIT $perPage OFFSET $offset");
                                $cnt = $offset + 1;
                                $count = mysqli_num_rows($query);
                                if($count > 0){
                                    while($row = mysqli_fetch_array($query)) { ?>
                                        <tr>
                                            <td><?php echo $cnt;?></td>
                                            <td><?php echo $row['AptNumber'];?></td>
                                            <td><p> <?php echo $row['AptDate']?> </p></td> 
                                            <td><?php echo $row['AptTime']?></td> 
                                            <td><?php $status=$row['Status'];
                                            if($status==''){
                                                echo "Waiting for confirmation";   
                                            } elseif($status=='Selected'){
                                                echo "Accepted";
                                            } elseif($status=='Rejected'){
                                                echo "Declined";
                                            } else{
                                                echo $status;
                                            }
                                            ?>  </td>   
                                            <td><a href="appointment-detail.php?aptnumber=<?php echo $row['AptNumber'];?>" class="btn btn-primary">View</a></td>       
                                        </tr>
                                    <?php $cnt=$cnt+1; } 
                                } else { ?>
                                    <tr>
                                        <th colspan="6" style="color:red">No Record Found</th>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                        
                        <!-- Pagination Controls for Appointment History -->
                        <?php if ($totalPages > 1): ?>
                        <div class="pagination-wrapper" style="margin-top: 20px; text-align: center;">
                            <nav>
                                <ul class="pagination" style="display: inline-block;">
                                    <?php if ($page > 1): ?>
                                        <li><a href="?hist_page=<?php echo ($page - 1); ?>" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>
                                    <?php else: ?>
                                        <li class="disabled"><span aria-hidden="true">&laquo;</span></li>
                                    <?php endif; ?>
                                    
                                    <?php
                                    $startPage = max(1, $page - 2);
                                    $endPage = min($totalPages, $page + 2);
                                    for ($i = $startPage; $i <= $endPage; $i++):
                                    ?>
                                        <li <?php echo ($i == $page) ? 'class="active"' : ''; ?>>
                                            <a href="?hist_page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                        </li>
                                    <?php endfor; ?>
                                    
                                    <?php if ($page < $totalPages): ?>
                                        <li><a href="?hist_page=<?php echo ($page + 1); ?>" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>
                                    <?php else: ?>
                                        <li class="disabled"><span aria-hidden="true">&raquo;</span></li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                            <p style="margin-top: 10px; color: #666;">
                                Showing <?php echo $offset + 1; ?> to <?php echo min($offset + $perPage, $totalRecords); ?> of <?php echo $totalRecords; ?> appointments
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include_once('includes/footer.php');?>
<!-- move top -->
<button onclick="topFunction()" id="movetop" title="Go to top">
	<span class="fa fa-long-arrow-up"></span>
</button>
<script>
	// When the user scrolls down 20px from the top of the document, show the button
	window.onscroll = function () {
		scrollFunction()
	};

	function scrollFunction() {
		if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
			document.getElementById("movetop").style.display = "block";
		} else {
			document.getElementById("movetop").style.display = "none";
		}
	}

	// When the user clicks on the button, scroll to the top of the document
	function topFunction() {
		document.body.scrollTop = 0;
		document.documentElement.scrollTop = 0;
	}
$(function(){
    var dtToday = new Date();
    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();
    if(day < 10)
        day = '0' + day.toString();
    
    var maxDate = year + '-' + month + '-' + day;
    $('#adate').attr('min', maxDate);
});

// Handle service selection and availability checking
var totalDuration = 0;

// Function to check stylist availability and update time slots using vanilla JS
function checkAvailability() {
    var selectedDate = document.getElementById('adate').value;
    var selectedStylist = document.getElementById('stylist').value;
    var selectedServices = document.querySelectorAll('input[name="services[]"]:checked').length;
    
    if (selectedDate && selectedStylist && selectedServices > 0 && totalDuration > 0) {
        document.getElementById('timeSlotHelp').style.display = 'block';
        document.getElementById('atime').innerHTML = '<option value="">Loading available slots...</option>';
        document.getElementById('atime').disabled = true;
        
        // Use XMLHttpRequest instead of jQuery AJAX
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'check_stylist_availability.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        
        xhr.onload = function() {
            if (xhr.status === 200) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.status === 'success') {
                        if (response.slots.length > 0) {
                            var options = '<option value="">Select Time</option>';
                            for (var i = 0; i < response.slots.length; i++) {
                                options += '<option value="' + response.slots[i].value + '">' + response.slots[i].label + '</option>';
                            }
                            document.getElementById('atime').innerHTML = options;
                            document.getElementById('atime').disabled = false;
                        } else {
                            document.getElementById('atime').innerHTML = '<option value="">No available slots for this stylist on this date</option>';
                            document.getElementById('atime').disabled = true;
                        }
                    } else {
                        document.getElementById('atime').innerHTML = '<option value="">Error loading slots</option>';
                        document.getElementById('atime').disabled = true;
                    }
                } catch(e) {
                    console.error('JSON Parse Error:', e);
                    document.getElementById('atime').innerHTML = '<option value="">Error loading slots</option>';
                    document.getElementById('atime').disabled = true;
                }
            } else {
                document.getElementById('atime').innerHTML = '<option value="">Error loading slots</option>';
                document.getElementById('atime').disabled = true;
            }
        };
        
        xhr.onerror = function() {
            document.getElementById('atime').innerHTML = '<option value="">Error loading slots</option>';
            document.getElementById('atime').disabled = true;
        };
        
        xhr.send('stylist_id=' + selectedStylist + '&appointment_date=' + selectedDate + '&total_duration=' + totalDuration);
    } else {
        document.getElementById('atime').innerHTML = '<option value="">Please select date, services, and stylist first</option>';
        document.getElementById('atime').disabled = true;
        document.getElementById('timeSlotHelp').style.display = 'none';
    }
}

// Service selection handlers with jQuery
$(document).ready(function() {
    // Add click event to checkbox items
    $('.service-checkbox-item').on('click', function(e) {
        // Don't trigger if clicking directly on checkbox
        if (e.target.type !== 'checkbox') {
            var checkbox = $(this).find('input[type="checkbox"]');
            checkbox.prop('checked', !checkbox.prop('checked'));
            checkbox.trigger('change');
        }
    });

    // Handle checkbox change
    $('input[name="services[]"]').on('change', function() {
        var parentLabel = $(this).closest('.service-checkbox-item');
        
        if ($(this).is(':checked')) {
            parentLabel.addClass('selected');
        } else {
            parentLabel.removeClass('selected');
        }
        
        updateSelectedServices();
    });

    // Update selected services summary
    function updateSelectedServices() {
        var selectedServices = [];
        var totalCost = 0;
        totalDuration = 0; // Update global variable
        
        $('input[name="services[]"]:checked').each(function() {
            var serviceItem = $(this).closest('.service-checkbox-item');
            var serviceName = serviceItem.find('.service-name').text();
            var serviceCostText = serviceItem.find('.service-cost').text();
            var serviceCost = parseFloat(serviceCostText.split('|')[0].replace('Rs. ', '').replace(',', '').trim());
            var serviceDuration = parseInt($(this).attr('data-duration'));
            
            selectedServices.push(serviceName);
            totalCost += serviceCost;
            totalDuration += serviceDuration;
        });
        
        if (selectedServices.length > 0) {
            var hours = Math.floor(totalDuration / 60);
            var minutes = totalDuration % 60;
            var durationText = '';
            if (hours > 0) {
                durationText = hours + ' hr';
                if (minutes > 0) {
                    durationText += ' ' + minutes + ' min';
                }
            } else {
                durationText = minutes + ' min';
            }
            
            var summaryText = selectedServices.join(', ') + ' <br><strong>Total Cost: Rs. ' + totalCost.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}) + ' | Duration: ' + durationText + '</strong>';
            $('#selectedServicesList').html(summaryText);
            $('#selectedServicesSummary').addClass('show');
            
            // Check availability after services are selected
            checkAvailability();
        } else {
            $('#selectedServicesSummary').removeClass('show');
            totalDuration = 0;
            // Reset time slots when no services selected
            document.getElementById('atime').innerHTML = '<option value="">Please select services first</option>';
            document.getElementById('atime').disabled = true;
        }
    }
});

// Trigger availability check when date, stylist change
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('adate').addEventListener('change', checkAvailability);
    document.getElementById('stylist').addEventListener('change', checkAvailability);
});
</script>
<!-- /move top -->
</body>

</html><?php } ?>