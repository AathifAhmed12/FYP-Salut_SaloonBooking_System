<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

// MUST set content type BEFORE any output
header('Content-Type: application/json');

// Get parameters
$stylistID = isset($_POST['stylist_id']) ? intval($_POST['stylist_id']) : 0;
$appointmentDate = isset($_POST['appointment_date']) ? $_POST['appointment_date'] : '';
$totalDuration = isset($_POST['total_duration']) ? intval($_POST['total_duration']) : 60;

if ($stylistID == 0 || empty($appointmentDate) || $totalDuration <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid parameters']);
    exit();
}

// Get all ACCEPTED booked time slots for this stylist on this date
// Only appointments with Status='Selected' (accepted by admin) will block time slots
// Pending (NULL) and Rejected appointments do NOT block slots
$query = mysqli_query($con, "SELECT AptTime, ServiceName FROM tblbook WHERE StylistID='$stylistID' AND AptDate='$appointmentDate' AND Status='Selected'");

$bookedSlots = [];
if ($query) {
    while ($row = mysqli_fetch_array($query)) {
        $startTime = $row['AptTime'];
        $serviceNames = explode(',', $row['ServiceName']);
        
        // Calculate duration for this booking
        $bookingDuration = 0;
        foreach ($serviceNames as $serviceName) {
            $serviceName = trim($serviceName);
            // Check if Duration column exists, if not use default 60
            $serviceQuery = mysqli_query($con, "SELECT Duration FROM tblservices WHERE ServiceName='$serviceName' LIMIT 1");
            if ($serviceQuery && $serviceRow = mysqli_fetch_array($serviceQuery)) {
                $duration = isset($serviceRow['Duration']) ? intval($serviceRow['Duration']) : 60;
                $bookingDuration += $duration;
            } else {
                $bookingDuration += 60; // Default if service not found
            }
        }
        
        // If no duration found, default to 60 minutes
        if ($bookingDuration == 0) {
            $bookingDuration = 60;
        }
        
        // Store the booking with start time and end time
        $bookedSlots[] = [
            'start' => $startTime,
            'duration' => $bookingDuration
        ];
    }
}

// Generate available time slots (9 AM to 10 PM)
$availableSlots = [];
for ($hour = 9; $hour < 22; $hour++) {
    $timeSlot = sprintf('%02d:00', $hour);
    $isAvailable = checkAvailability($timeSlot, $totalDuration, $bookedSlots);
    
    if ($isAvailable) {
        $displayHourStart = $hour % 12;
        $displayHourStart = $displayHourStart ? $displayHourStart : 12;
        $period = $hour < 12 ? 'AM' : 'PM';
        
        $availableSlots[] = [
            'value' => $timeSlot,
            'label' => $displayHourStart . ':00 ' . $period
        ];
    }
}

echo json_encode([
    'status' => 'success',
    'slots' => $availableSlots
]);

function checkAvailability($requestedTime, $requestedDuration, $bookedSlots) {
    $requestedStart = strtotime($requestedTime);
    $requestedEnd = $requestedStart + ($requestedDuration * 60);
    
    foreach ($bookedSlots as $booking) {
        $bookedStart = strtotime($booking['start']);
        $bookedEnd = $bookedStart + ($booking['duration'] * 60);
        
        // Check if there's any overlap
        if (($requestedStart < $bookedEnd) && ($requestedEnd > $bookedStart)) {
            return false; // Overlap found, not available
        }
    }
    
    return true; // No overlap, available
}
?>

