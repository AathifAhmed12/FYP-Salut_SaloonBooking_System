-- Stylist Table Structure for Salon Booking System
-- This table will store stylist information

CREATE TABLE `tblstylist` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `StylistName` varchar(200) DEFAULT NULL,
  `StylistEmail` varchar(200) DEFAULT NULL,
  `StylistPhone` bigint(10) DEFAULT NULL,
  `Specialization` varchar(500) DEFAULT NULL,
  `Experience` varchar(100) DEFAULT NULL,
  `Bio` mediumtext DEFAULT NULL,
  `Image` varchar(200) DEFAULT NULL,
  `Status` varchar(20) DEFAULT 'Active',
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Sample data for testing
INSERT INTO `tblstylist` (`StylistName`, `StylistEmail`, `StylistPhone`, `Specialization`, `Experience`, `Bio`, `Status`) VALUES
('Sarah Johnson', 'sarah.johnson@salon.com', 1234567890, 'Hair Styling, Hair Color', '5 years', 'Professional hair stylist with expertise in modern cuts and coloring techniques.', 'Active'),
('Mike Rodriguez', 'mike.rodriguez@salon.com', 1234567891, 'Beard Trim, Shave', '3 years', 'Specialized in men\'s grooming and traditional shaving techniques.', 'Active'),
('Emma Davis', 'emma.davis@salon.com', 1234567892, 'Facial Treatment, Make Up', '7 years', 'Certified esthetician with advanced training in skincare and bridal makeup.', 'Active'),
('David Wilson', 'david.wilson@salon.com', 1234567893, 'Manicure, Pedicure', '4 years', 'Professional nail technician specializing in nail art and foot care.', 'Active');

-- Update tblbook table to include stylist information
ALTER TABLE `tblbook` ADD `StylistID` int(10) DEFAULT NULL AFTER `ServiceName`;
ALTER TABLE `tblbook` ADD `StylistName` varchar(200) DEFAULT NULL AFTER `StylistID`;

-- Add foreign key constraint (optional)
-- ALTER TABLE `tblbook` ADD CONSTRAINT `fk_stylist` FOREIGN KEY (`StylistID`) REFERENCES `tblstylist` (`ID`);
